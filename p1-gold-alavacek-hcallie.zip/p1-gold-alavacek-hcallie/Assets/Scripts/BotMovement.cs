using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BotMovement : MonoBehaviour
{
    public bool isFlying;
    public GameObject projectile;
    public bool destroyAfterTime;
    public Vector3 shootingDirection;


    GameObject currentProjectile;

    public AudioClip doTheRoar;

    //fairy death, fast movement of bats, aquamentus shooting
    bool gottaGoFast;
    float gottaGoFastTimer;
    bool canShoot;

    bool decidedStartDirection;

    public bool forwardBackMovement;

    float xMax;
    float xMin;


    Rigidbody rb;
    GridMovement adjust;

    float xVelocity = 0.01f;
    float yVelocity = 0.0f;

    Vector3 movingDirection;

    LayerMask wall;

    public float speed;



    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        adjust = GetComponent<GridMovement>();

        //float horizontal = Random.Range(0, 2) * 2 - 1;

        //Debug.Log("horizontal direction start: " + horizontal.ToString());
        //movingDirection = new Vector3(horizontal, 0.0f, 0.0f);
        //xVelocity = xVelocity * horizontal;

        decidedStartDirection = false;
        wall = 1;

        gottaGoFast = false;
        if (isFlying)
        {
            gottaGoFastTimer = 7.0f;
        }
        else
        {
            gottaGoFastTimer = 4.0f;
        }

        if (destroyAfterTime)
        {
            gottaGoFastTimer = 3.0f;
        }

        if (forwardBackMovement)
        {
            xMin = GetComponent<Transform>().position.x - 1.5f;
            xMax = GetComponent<Transform>().position.x + 1.5f;
        }

    }

    // Update is called once per frame
    void Update()
    {
        //keep still when still spawning in
        if (GetComponent<Animator>() != null && GetComponent<Animator>().GetCurrentAnimatorClipInfo(0)[0].clip.name == "s1")
        {
            return;
        }



        if (GetComponent<Inventory>() != null)
        {
            float moveChance = Random.Range(0, 200);


            if (moveChance == 1.0f && GetComponent<Inventory>().hasBoomerang == true)
            {
                xVelocity = 0.0f;
                yVelocity = 0.0f;
                adjust.ReadjustGrid(xVelocity, yVelocity);

                BoomerangThrower();
            }
            else if (GetComponent<Inventory>().hasBoomerang == true)
            {
                xVelocity = movingDirection.x * 0.01f;
                yVelocity = movingDirection.y * 0.01f;
                rb.velocity = new Vector3(xVelocity, yVelocity, 0);

                MakeRandomMovement();
            }
            else
            {
                xVelocity = 0.0f;
                yVelocity = 0.0f;
                adjust.ReadjustGrid(xVelocity, yVelocity);
            }

            PlayDirectionalAnimation();
        }
        else if (forwardBackMovement)
        {
            RandomOneDirectionMovement();

            //float moveChance = Random.Range(0, 300);

            if (projectile != null && canShoot)
            {
                GetComponent<Animator>().Play("aquamentusShooting");
                TripleShot(shootingDirection);
            }
        }
        else
        {
            //make a random movement based on random number generator and walls
            MakeRandomMovement();
        }




        //update whether should go fast or not
        if (isFlying || projectile != null)
        {
            IsFlyingTimer();
        }

        //rb.velocity = movingDirection;
        transform.position = transform.position + new Vector3(xVelocity, yVelocity, 0);

    }

    private void IsFlyingTimer()
    {
        gottaGoFastTimer -= Time.deltaTime;
        if (gottaGoFastTimer <= 0)
        {
            if (destroyAfterTime)
            {
                //fairy
                Destroy(gameObject);
            }
            else if (isFlying)
            {
                
                //keeves
                gottaGoFast = !gottaGoFast;


                gottaGoFastTimer = 7.0f;

            }
            else if (projectile != null)
            {
                //aquamentus
                canShoot = true;
            }



        }

        if (gottaGoFast)
        {
            GetComponent<Animator>().speed = 1.5f;
        }
        else
        {
            GetComponent<Animator>().speed = 1.0f;
        }
    }

    private void MakeRandomMovement()
    {
        RaycastHit hit1;
        bool justMadeMove = false;

        if (decidedStartDirection == false)
        {
            float horizontal = Random.Range(0, 2) * 2 - 1;

            //Debug.Log("horizontal direction start: " + horizontal.ToString());
           
            if (Physics.Raycast(transform.position, new Vector3(horizontal, 0.0f, 0.0f), out hit1, 1.51f * (speed), wall)){
                movingDirection = new Vector3(horizontal, 0.0f, 0.0f);
            }
            else
            {
                horizontal = horizontal * (-1.0f);
                movingDirection = new Vector3(horizontal, 0.0f, 0.0f);
            }
            xVelocity = xVelocity * horizontal * speed;
            decidedStartDirection = true;

        }

        RaycastHit hit;

        float changeDirection = Random.Range(0, 400);


        //float speed = 1.0f;
        //for flying mobs
        if (isFlying && gottaGoFast)
        {
            speed = 2.3f;
            if (xVelocity != 0)
            {
                xVelocity = 0.01f * speed * xVelocity / Mathf.Abs(xVelocity);
            }
            if (yVelocity != 0)
            {
                yVelocity = 0.01f * speed * yVelocity / Mathf.Abs(yVelocity);
            }

        }
        else if (isFlying)
        {
            speed = 1.0f;
        }

        //Debug.Log(changeDirection.ToString());
        if ((changeDirection == 1 || Physics.Raycast(transform.position, movingDirection, out hit, 0.51f * (speed), wall)))
        {

            //Debug.Log("wall");
            if (xVelocity != 0)
            {
                //change to y
                float changeY = Random.Range(0, 2) * 2 - 1;

                movingDirection = new Vector3(0, changeY, 0);

                //Debug.Log("Y to " + changeY.ToString() + "?");
                if (!Physics.Raycast(transform.position, movingDirection, out hit, 1.51f * (speed), wall))
                {
                    //Debug.Log("Y to " + changeY.ToString());

                    //xVelocity = 0.0f;
                    yVelocity = 0.01f * changeY * speed;
                }
                else
                {
                    //Debug.Log("Would have hit wall");
                    changeY = changeY * (-1.0f);
                    movingDirection = new Vector3(0, changeY, 0);
                    //xVelocity = 0.0f;
                    yVelocity = 0.01f * changeY * speed;

                    //Debug.Log("Y to " + changeY.ToString());
                }

                if (!isFlying || (changeDirection % 2 == 1 && changeDirection < 30))
                {
                    xVelocity = 0.0f;
                }
                justMadeMove = true;


            }
            if (yVelocity != 0 && (!justMadeMove || isFlying))
            {
                //change to x
                float changeX = Random.Range(0, 2) * 2 - 1;


                movingDirection = new Vector3(changeX, 0, 0);
                //Debug.Log("X to " + changeX.ToString() + "?");
                if (!Physics.Raycast(transform.position, movingDirection, out hit, 1.51f * (speed), wall))
                {
                    //Debug.Log("X to " + changeX.ToString());

                    xVelocity = 0.01f * changeX * speed;
                    //yVelocity = 0.0f;
                }
                else
                {
                    //Debug.Log("Would have hit wall");

                    changeX = changeX * (-1.0f);
                    movingDirection = new Vector3(changeX, 0, 0);

                    xVelocity = 0.01f * changeX * speed;
                    //yVelocity = 0.0f;

                    //Debug.Log("X to " + changeX.ToString());
                }

                if (!isFlying || (changeDirection % 2 == 0 && changeDirection < 30))
                {
                    yVelocity = 0.0f;
                }

            }

            movingDirection = new Vector3(xVelocity / 0.01f, yVelocity / 0.01f, 0);

            if (!isFlying && GetComponent<GridMovement>() != null)
            {
                adjust.ReadjustGrid(xVelocity, yVelocity);
            }

        }
    }

    private void BoomerangThrower()
    {

        if (GetComponent<Inventory>().hasBoomerang == true || currentProjectile != null)
        {
            Inventory inventory = GetComponent<Inventory>();


            GameObject boomerang = Instantiate(inventory.boomerangPrefab, rb.position + movingDirection * 1.0f, Quaternion.identity);

            inventory.hasBoomerang = false;

            boomerang.GetComponent<Projectile>().SetSender(this.gameObject);
            //Debug.Log("instantiated");
            //Projectile arrowYeet = arrow.GetComponent<Projectile>();
            //Debug.Log("got component");
            boomerang.GetComponent<Projectile>().Launch(movingDirection, 400);

            //rb.velocity = new Vector3(0,0,0);

            currentProjectile = boomerang;

            adjust.ReadjustGrid(xVelocity, yVelocity);
        }
    }

    void PlayDirectionalAnimation()
    {
        if (movingDirection.x > 0)
        {
            GetComponent<Animator>().Play("goriyaRight");
        }
        else if (movingDirection.x < 0)
        {
            GetComponent<Animator>().Play("goriyaLeft");
        }
        else if (movingDirection.y > 0)
        {
            GetComponent<Animator>().Play("goriyaUp");
        }
        else
        {
            GetComponent<Animator>().Play("goriyaDown");
        }

    }

    void RandomOneDirectionMovement()
    {
        RaycastHit hit;
        float changeDirection = Random.Range(0, 100);

        if ((changeDirection == 1 || GetComponent<Transform>().position.x >= xMax || GetComponent<Transform>().position.x <= xMin))
        {

            xVelocity = xVelocity * (-1.0f);
            yVelocity = yVelocity * (-1.0f);
            movingDirection = movingDirection * -1.0f;

        }
    }

    void TripleShot(Vector3 direction)
    {
        AudioSource.PlayClipAtPoint(doTheRoar, Camera.main.transform.position);

        GameObject tripleProjectile1 = Instantiate(projectile, rb.position + direction * 1.0f, Quaternion.identity);
        tripleProjectile1.GetComponent<Projectile>().SetSender(this.gameObject);

        GameObject tripleProjectile2 = Instantiate(projectile, rb.position + direction + new Vector3(0, 1.0f, 0) * 1.0f, Quaternion.identity);
        tripleProjectile2.GetComponent<Projectile>().SetSender(this.gameObject);

        GameObject tripleProjectile3 = Instantiate(projectile, rb.position + direction + new Vector3(0, -1.0f, 0) * 1.0f, Quaternion.identity);
        tripleProjectile3.GetComponent<Projectile>().SetSender(this.gameObject);

        tripleProjectile1.GetComponent<Projectile>().Launch(direction, 400);
        tripleProjectile2.GetComponent<Projectile>().Launch(direction + new Vector3(0, 0.3f, 0), 400);
        tripleProjectile3.GetComponent<Projectile>().Launch(direction + new Vector3(0, -0.3f, 0), 400);

        gottaGoFastTimer = 5.5f;
        canShoot = false;

    }
}




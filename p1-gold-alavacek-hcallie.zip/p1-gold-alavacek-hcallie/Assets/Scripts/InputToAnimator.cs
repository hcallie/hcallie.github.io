using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputToAnimator : MonoBehaviour
{
    
    Animator animator;
    ArrowKeyMovement player;

    bool ouch;
    bool shot;
    bool stab;
    bool holdingGirlBossItem;
    bool holdingNewWeapon;

    string previousAnimation;

    Vector3 directionFacing;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();

        if (GetComponent<ArrowKeyMovement>() != null)
        {
            player = GetComponent<ArrowKeyMovement>();
        }

    }

    // Update is called once per frame
    void Update()
    {
        if (player.hasControl)
        {   
            animator.ResetTrigger("Hit");

            if (GetComponent<ArrowKeyMovement>() != null)
            {
                animator.SetFloat("horizontalInput", Input.GetAxisRaw("Horizontal"));
                animator.SetFloat("verticalInput", Input.GetAxisRaw("Vertical"));
            }
            else
            {
                animator.SetFloat("horizontalAxis", GetComponent<Rigidbody>().velocity.x);
                animator.SetFloat("verticalAxis", GetComponent<Rigidbody>().velocity.y);
            }


            if (Input.GetAxisRaw("Horizontal") == 0 && Input.GetAxisRaw("Vertical") == 0)
            {
                animator.speed = 0.0f;
            }
            else
            {
                animator.speed = 1.0f;
            }

        }
        else if (ouch)
        {
            animator.SetTrigger("Hit");
            //GetComponent<Animation>().Play("")
        }
        else if (shot)
        {
            ShootBowAnim();
        }
        else if (stab)
        {
            SwingSwordAnim();
        }
        //triforce, new equipment (bow, sword, boomerang)
        else if (holdingGirlBossItem)
        {
            GetComponent<Animator>().Play("WOWIE");
        }
        else if (holdingNewWeapon)
        {
            GetComponent<Animator>().Play("NewWeaponSlay");
        }
    }

    public void IsHit(bool ouch_in)
    {
        ouch = ouch_in;
        if (ouch == true)
        {
            previousAnimation = GetComponent<Animator>().GetCurrentAnimatorClipInfo(0)[0].clip.name;
            
        }
        else
        {
            GetComponent<Animator>().Play(previousAnimation);
        }
    }

    public void IsShooting(bool shot_in)
    {

       shot = shot_in;
       GetComponent<Animator>().Play(previousAnimation);

        //GetComponent<SpriteRenderer>().sprite = shootBow[getDirection()];
    }

    public void IsShooting(bool shot_in, Vector3 direction)
    {
        shot = shot_in;
        directionFacing = direction;

        previousAnimation = GetComponent<Animator>().GetCurrentAnimatorClipInfo(0)[0].clip.name;

        //because runLeft, ONLY RUNLEFT, is tweaking af what the heck man if i remove this all the other states are like f it we ball
        //but runleft has a panic attack #notslay
        animator.SetFloat("horizontalInput", 0.0f);

        ShootBowAnim();
    }

    public void IsShootingLaserSword(bool shot_in)
    {

       shot = shot_in;
       GetComponent<Animator>().Play(previousAnimation);

        //GetComponent<SpriteRenderer>().sprite = shootBow[getDirection()];
    }

    public void IsShootingLaserSword(bool shot_in, Vector3 direction)
    {
        shot = shot_in;
        directionFacing = direction;

        //eviousAnimation = GetComponent<Animator>().GetCurrentAnimatorClipInfo(0)[0].clip.name;
        //because runLeft, ONLY RUNLEFT, is tweaking af what the heck man if i remove this all the other states are like f it we ball
        //but runleft has a panic attack #notslay
        animator.SetFloat("horizontalInput", 0.0f);

        ShootBowAnim();
    }

    public void IsHoldingNewItem(bool holdingNewWeaponIn)
    {    
         holdingNewWeapon = holdingNewWeaponIn;
        if (holdingNewWeapon)
        {
            previousAnimation = GetComponent<Animator>().GetCurrentAnimatorClipInfo(0)[0].clip.name;

            //because runLeft, ONLY RUNLEFT, is tweaking af what the heck man if i remove this all the other states are like f it we ball
            //but runleft has a panic attack #notslay
            animator.SetFloat("horizontalInput", 0.0f);

        }
        else
        {
            GetComponent<Animator>().Play(previousAnimation);
        }
    }

    public void IsTwoHandHoldingItem(bool holdingGirlBossItemIn)
    {
        holdingGirlBossItem = holdingGirlBossItemIn;
        if (holdingGirlBossItem)
        {
            previousAnimation = GetComponent<Animator>().GetCurrentAnimatorClipInfo(0)[0].clip.name;

            animator.SetFloat("horizontalInput", 0.0f);

        }
        else
        {
            GetComponent<Animator>().Play(previousAnimation);
        }
    }

    public void IsSwingingSword(bool stab_in)
    {
        // Debug.Log("[InputToAnimator] [Sword] IsSwingingSword called");
        stab = stab_in;
        GetComponent<Animator>().Play(previousAnimation);
    }

    public void IsSwingingSword(bool stab_in, Vector3 direction)
    {
        stab = stab_in;
        directionFacing = direction;

        previousAnimation = GetComponent<Animator>().GetCurrentAnimatorClipInfo(0)[0].clip.name;

        SwingSwordAnim();
    }

    //RIGHT - 0
    //LEFT - 1
    //UP - 2
    //DOWN - 3
    private void ShootBowAnim()
    {
        //because runLeft, ONLY RUNLEFT, is tweaking af what the heck man if i remove this all the other states are like f it we ball
        //but runleft has a panic attack #notslay
        animator.SetFloat("horizontalInput", 0.0f);

        if (directionFacing.x > 0) { GetComponent<Animator>().Play("shootBowRight"); }
        else if (directionFacing.x < 0) { GetComponent<Animator>().Play("shootBowLeft"); }
        else if (directionFacing.y > 0) { GetComponent<Animator>().Play("shootBowUp"); }
        else { GetComponent<Animator>().Play("shootBowDown"); }
    }

    private void SwingSwordAnim()
    {
        //because runLeft, ONLY RUNLEFT, is tweaking af what the heck man if i remove this all the other states are like f it we ball
        //but runleft has a panic attack #notslay
        animator.SetFloat("horizontalInput", 0.0f);

        if (directionFacing.x > 0) { GetComponent<Animator>().Play("swingSwordRight"); }
        else if (directionFacing.x < 0) { GetComponent<Animator>().Play("swingSwordLeft"); }
        else if (directionFacing.y > 0) { GetComponent<Animator>().Play("swingSwordUp"); }
        else { GetComponent<Animator>().Play("swingSwordDown"); }
    }
    /*
    IEnumerator WaitOneFrame()
    {
        yield return null;
    }*/
}

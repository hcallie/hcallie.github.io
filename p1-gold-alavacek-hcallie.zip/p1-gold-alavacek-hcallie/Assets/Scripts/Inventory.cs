using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    int rupeeCount;
    int arrowCount;

    public GameObject arrowPrefab;
    public GameObject boomerangPrefab;
    public GameObject bombPrefab;
    public GameObject swordPrefab;
    public GameObject laserSwordPrefab;
    public GameObject switchRodPrefab;
    public GameObject orbPrefab;
    public GameObject bowPrefab;

    public GameObject swordUp;
    public GameObject swordDown;
    public GameObject swordLeft;
    public GameObject swordRight;

    public GameObject bombExplosionCollider;
    public GameObject bombExplosionThick;
    public GameObject bombExplosionThin;

    public Sprite explosionThick;
    public Sprite explosionThin;

    // Which weapon player holding
    public bool holdingStandardWeapon = true; // x
    public bool holdingAltWeapon = false; // z
    public bool weaponToggle;

    // Weapon inventory
    public bool hasSword = true;
    public bool hasBow;
    public bool hasBoomerang;
    public bool hasBomb;
    public bool hasSwitchRod;

    public bool laserSwordShooting;

    int numKeys;
    int numBombs = 0;

    private void Start()
    {
        numKeys = 0;
        laserSwordShooting = false;
    }

    public void AddRupees(int numRupees)
    {
        rupeeCount += numRupees;
    }

    void Update()
    {
        CheckForWeaponToggle();
    }

    void CheckForWeaponToggle()
    {

        if (Input.GetKeyDown(KeyCode.Space))
        {
            weaponToggle = true;

        }
        else
        {
            weaponToggle = false;
        }
    }

    public int GetRupees()
    {
        return rupeeCount;
    }

    public int GetArrows()
    {
        //TODO: implement real arrows
        return rupeeCount;
    }

    public void UseArrow()
    {
        //TODO: implement real arrows
        rupeeCount--;

    }

    // Key functions
    public int NumKeys()
    {
        return numKeys;
    }

    public void PickedUpKey()
    {
        numKeys++;
    }

    public void UseKey()
    {
        numKeys--;
    }

    // Bomb Functions
    public int NumBombs()
    {
        return numBombs;
    }

    public void PickedUpBomb()
    {
        numBombs++;
    }

    public void UseBomb()
    {
        numBombs--;
    }
}
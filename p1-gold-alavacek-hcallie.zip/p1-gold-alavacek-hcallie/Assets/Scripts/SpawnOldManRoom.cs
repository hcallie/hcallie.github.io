using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnOldManRoom : MonoBehaviour
{
    public GameObject[] fireAndMan;
    public Vector3[] spawnLocation;

    public GameObject[] lettersForMessage;
    // public Vector3[] lettersLocation;

    bool hasEnteredBefore = false;

    void Start()
    {
        for (int i = 0; i < lettersForMessage.Length; i++)
        {
            lettersForMessage[i].gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!hasEnteredBefore)
        {
            StartCoroutine(SpawnOldMan());

            StartCoroutine(SpawnOldManMessage());
        }
        hasEnteredBefore = true;
    }

    IEnumerator SpawnOldMan()
    {
        yield return new WaitForSeconds(1.0f);

        Debug.Log("[SpawnOldManRoom] Spawning fire and old man");

        Vector3 position;

        for (int i = 0; i < fireAndMan.Length; i++)
        {
            Debug.Log("[SpawnOldManRoom] i = " + i);
            position = spawnLocation[i];
            Instantiate(fireAndMan[i]);
            fireAndMan[i].transform.position = position;
            fireAndMan[i].gameObject.SetActive(true);

            // yield return new WaitForSeconds(3.0f);
        }

        yield return null;

    }

    IEnumerator SpawnOldManMessage()
    {
        yield return new WaitForSeconds(0.8f);

        Debug.Log("[SpawnOldManRoom] Message coroutine");

        Vector3 position;

        for (int i = 0; i < lettersForMessage.Length; i++)
        {
            lettersForMessage[i].gameObject.SetActive(true);
            yield return new WaitForSeconds(0.2f);
        }

    }
}

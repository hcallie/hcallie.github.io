using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MobDeath : MonoBehaviour
{
    //public Sprite[] deathAnim;

    public GameObject[] droppedItems;

    private GameObject assignedRoom;

    public AudioClip mobDeathNoise;
    // Start is called before the first frame update

    void Start()
    {
        GetComponent<HasHealth>().deathCallback += OnDeath;
    }
    
    void OnDeath()
    {
        GetComponent<SpriteRenderer>().color = new Color(255f, 255f, 255f);
        StartCoroutine(Death());
        AudioSource.PlayClipAtPoint(mobDeathNoise, Camera.main.transform.position);

    }

    
    //TODO: fix death anim
    IEnumerator Death()
    {
        Debug.Log("inside coroutine");



        int spawnIt = Random.Range(0, droppedItems.Length);

        Debug.Log("Spawning: " + spawnIt.ToString());
        Vector3 position = gameObject.GetComponent<Transform>().position;


        GetComponent<DamageZone>().enabled = false;
        GetComponent<BotMovement>().enabled = false;
        GetComponent<BoxCollider>().enabled = false;


        GetComponent<Animator>().Play("enemyDeath");

        yield return new WaitForSeconds(0.3f);

        if (droppedItems[spawnIt] != null)
        {
            GameObject newItem = Instantiate(droppedItems[spawnIt]);
            newItem.GetComponent<Transform>().position = position;
            newItem.SetActive(true);
        }

        if(assignedRoom != null)
        {
            assignedRoom.GetComponent<spawnMobs>().DecrementNumEnemies();
        }


        Destroy(gameObject);

        yield break;
    }

    public void SetAssignedRoom(GameObject roomIn)
    {
        assignedRoom = roomIn;
    }
}

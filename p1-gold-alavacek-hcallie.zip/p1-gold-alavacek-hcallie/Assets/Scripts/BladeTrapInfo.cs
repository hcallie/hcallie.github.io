using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BladeTrapInfo : MonoBehaviour
{
    public bool isMoving = false;

}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageZoneBomb : MonoBehaviour
{
    public int damageDone;

    public float thrust;

    public GameObject self;

    private void OnTriggerEnter(Collider collision)
    {
        //if it has health and we collide then merk that bish

        Debug.Log("[DamageZoneBomb] [Bomb] OnTriggerEnter called");

        HasHealth entity = collision.gameObject.GetComponent<HasHealth>();
        string collidedWithName = collision.gameObject.name;

        Debug.Log("[DamageZoneBomb] [Bomb] OnTriggerEnter collider name is " + collidedWithName);

        // Debug.Log("[DamageZoneBomb] [Bomb] Got entity: " + entity.tag + " and self:" + self.tag + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"); 

        if (entity != null && collidedWithName != self.name && !(self.tag == "Weapon" && entity.tag == "Player"))
        {
            if (entity.tag != "Player")
            {
                Vector3 direction = (collision.transform.position - transform.position).normalized;

                Debug.Log("[DamageZoneBomb] [Bomb] Changing entity health");

                if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
                {
                    direction.y = 0.0f;
                }
                else
                {
                    direction.x = 0.0f;
                }

                Vector3 knockback = direction * thrust;


                //change their health
                entity.ChangeHealth(damageDone, knockback);
            }
        }
    }

 }



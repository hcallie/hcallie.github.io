using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    Rigidbody yeetedObject;
    public Sprite yeetObjectL;
    public Sprite yeetObjectR;
    public Sprite yeetObjectU;
    public Sprite yeetObjectD;
    public bool differentSprites;

    public Sprite swordLeft;
    public Sprite swordRight;
    public Sprite swordUp;
    public Sprite swordDown;

    public bool willReturn;
    float flyingForce;

    Vector3 flyingDirection;
    GameObject Sender;
    Vector3 originalPosition;

    bool hasBeenZero = false;
    bool explodedBefore = false;

    // GameObject explosionNE;
    public GameObject projectileExplosionPrefabNE;
    public GameObject projectileExplosionPrefabNW;
    public GameObject projectileExplosionPrefabSE;
    public GameObject projectileExplosionPrefabSW;

    // Vector3 explosionSpawnLocation;
    // bool explosionTrigger;

    void Awake()
    {
        yeetedObject = GetComponent<Rigidbody>();
        originalPosition = GetComponent<Transform>().position;
        // explosionTrigger = false;
    }


    public void SetSender(GameObject senderIn)
    {
        Sender = senderIn;
    }

    public void Launch(Vector3 direction, float force)
    {
        if (!willReturn)
        {
            Shoot(direction);
        }
        else
        {
            flyingForce = force;
            flyingDirection = direction;
        }

        yeetedObject.AddForce(direction * force);
    }

    // for swords
    public void Swing(Vector3 direction)
    {

        Debug.Log("[Projectile] [Sword] Swing called, rendering sprite");

        if (direction.x == 1)
        {
            GetComponent<SpriteRenderer>().sprite = swordRight;
            GetComponent<BoxCollider>().size = new Vector3(GetComponent<BoxCollider>().size.y, GetComponent<BoxCollider>().size.x, GetComponent<BoxCollider>().size.z);

        }
        else if (direction.x == -1)
        {
            GetComponent<SpriteRenderer>().sprite = swordLeft;
            GetComponent<BoxCollider>().size = new Vector3(GetComponent<BoxCollider>().size.y, GetComponent<BoxCollider>().size.x, GetComponent<BoxCollider>().size.z);
        }
        else if (direction.y == 1)
        {
            GetComponent<SpriteRenderer>().sprite = swordUp;
        }
        else
        {
            GetComponent<SpriteRenderer>().sprite = swordDown;
        }
    }

    //for will not returns (arrows)
    private void Shoot(Vector3 direction)
    {
        // then has different sprites for launching
        if (differentSprites)
        {
            if (direction.x == 1)
            {
                GetComponent<SpriteRenderer>().sprite = yeetObjectR;
                GetComponent<BoxCollider>().size = new Vector3(GetComponent<BoxCollider>().size.y, GetComponent<BoxCollider>().size.x, GetComponent<BoxCollider>().size.z);

            }
            else if (direction.x == -1)
            {
                GetComponent<SpriteRenderer>().sprite = yeetObjectL;
                GetComponent<BoxCollider>().size = new Vector3(GetComponent<BoxCollider>().size.y, GetComponent<BoxCollider>().size.x, GetComponent<BoxCollider>().size.z);
            }
            else if (direction.y == 1)
            {
                GetComponent<SpriteRenderer>().sprite = yeetObjectU;
            }
            else
            {
                GetComponent<SpriteRenderer>().sprite = yeetObjectD;
            }
        }

    }

    private void OnCollisionEnter(Collision collision)
    {

        Debug.Log(collision.gameObject.name);

        string tag = collision.gameObject.tag;

        if (GetComponent<switchController>() != null && ((collision.gameObject.GetComponent<Rigidbody>() != null) || (collision.gameObject.tag == "heart") || (collision.gameObject.tag == "rupee") || (collision.gameObject.tag == "key")))
        {
            Debug.Log("Setting a switch object");
            switchController.SetHit(collision.gameObject);
        }
            
        if (((tag != "heart") && (tag != "rupee") && (tag != "key") && !willReturn) || (willReturn && Sender == null) || 
            (willReturn && collision.gameObject.name == Sender.name))
        {
            if (willReturn && Sender != null && collision.gameObject.name == Sender.name)
            {
                
                collision.gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
                Sender.GetComponent<Inventory>().hasBoomerang = true;

            }
            //yeetedObject.velocity = Vector3.zero;
            Debug.Log(collision.gameObject.name);


            
            // // ---------- Explosion ----------- //
            if (!explodedBefore && !willReturn && gameObject.GetComponent<ProjectileExplosion>() != null)
            {
                explodedBefore = true;
                Vector3 v = gameObject.GetComponent<Rigidbody>().position + new Vector3 (0.0f, 0.0f, -0.45f);
                gameObject.GetComponent<ProjectileExplosion>().explosionSpawnLocation = v;
                gameObject.GetComponent<ProjectileExplosion>().explosionTrigger = true;

                //yield return new WaitForSeconds(5.0f);

                gameObject.GetComponent<SpriteRenderer>().enabled = false;
                
            }
            else
            {
                Destroy(gameObject);
            }
        }
        /*
        Debug.Log("Collided with " + tag);
        if ((tag == "rupee") && willReturn && Sender.GetComponent<Inventory>() != null)
        {
            Sender.GetComponent<Inventory>().AddRupees(1);
            Destroy(collision.gameObject);
        }*/

        if (willReturn && collision.gameObject.name != Sender.name)
        {
            
            ReturnToSender();
        }

    }

    private void ReturnToSender()
    {
        yeetedObject.velocity = new Vector3(0, 0, 0);
        flyingDirection = flyingDirection * -1.0f;
        //flyingDirection = (originalPosition - GetComponent<Transform>().position).normalized;
        
        if (Mathf.Abs(flyingDirection.x) > Mathf.Abs(flyingDirection.y))
        {
            flyingDirection.y = 0.0f;
        }
        else
        {
            flyingDirection.x = 0.0f;
        }

        //GetComponent<GridMovement>().ReadjustGrid(flyingDirection.x, flyingDirection.y);

        yeetedObject.AddForce(flyingDirection * flyingForce);
    }

    private void Update()
    {
            
        if (willReturn)
        {
            if (yeetedObject.velocity == new Vector3(0, 0, 0))
            {
                hasBeenZero = true;

            }
            else if ((yeetedObject.velocity == new Vector3(0, 0, 0) && hasBeenZero))
            {
                ReturnToSender();
                // // ---------- Explosion ----------- // ?????

                /*if (!explodedBefore)
                {
                    explodedBefore = true;
                    Vector3 v = gameObject.GetComponent<Rigidbody>().position + new Vector3 (0.0f, 0.0f, -0.45f);
                    gameObject.GetComponent<ProjectileExplosion>().explosionSpawnLocation = v;
                    gameObject.GetComponent<ProjectileExplosion>().explosionTrigger = true;

                    //yield return new WaitForSeconds(5.0f);

                    gameObject.GetComponent<SpriteRenderer>().enabled = false;
                    
                }*/
            }
            else
            {
                hasBeenZero = false;
            }
        }


        if ((willReturn) && ((Mathf.Abs(originalPosition.x - GetComponent<Transform>().position.x) > 1.5f) ||
                (Mathf.Abs(originalPosition.y - GetComponent<Transform>().position.y) > 1.5f)))
        {
            ReturnToSender();
        } 
    }

    public static IEnumerator MoveObjectOverTime(Transform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {

        Debug.Log("[MoveBladeTrap] [Test] before lerp");
        Debug.Log("[MoveBladeTrap] [Test] pos, i: " + initialPosition.x + initialPosition.y + initialPosition.z);
        Debug.Log("[MoveBladeTrap] [Test] pos, f: " + finalPosition.x + finalPosition.y + finalPosition.z);
        
        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.position = newPosition;

            yield return null;
        }

        target.position = finalPosition;
    }

    IEnumerator ExplosionCoroutine()
    {
        while (true)
        {
            // if (explosionTrigger)
            // {
                // // ---------- Explosion ----------- //
                // // explosionSpawnLocation = gameObject.GetComponent<Rigidbody>().position + new Vector3 (0.0f, 0.0f, -0.45f);
                // // Destroy(gameObject);

                // GameObject explosionNE = Instantiate(projectileExplosionPrefabNE, explosionSpawnLocation + new Vector3(0.125f, 0.125f, 0.0f), Quaternion.identity);
                // GameObject explosionNW = Instantiate(projectileExplosionPrefabNW, explosionSpawnLocation + new Vector3(-0.125f, 0.125f, 0.0f), Quaternion.identity);
                // GameObject explosionSE = Instantiate(projectileExplosionPrefabSE, explosionSpawnLocation + new Vector3(0.125f, -0.125f, 0.0f), Quaternion.identity);
                // GameObject explosionSW = Instantiate(projectileExplosionPrefabSW, explosionSpawnLocation + new Vector3(-0.125f, -0.125f, 0.0f), Quaternion.identity);
                
                // yield return StartCoroutine(MoveObjectOverTime(explosionNE.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(0.125f, 0.125f, 0.0f), explosionSpawnLocation + new Vector3(1.5f, 1.5f, 0.0f), 2.0f));
                // yield return StartCoroutine(MoveObjectOverTime(explosionNE.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(-0.125f, 0.125f, 0.0f), explosionSpawnLocation + new Vector3(-1.5f, 1.5f, 0.0f), 2.0f));
                // yield return StartCoroutine(MoveObjectOverTime(explosionNE.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(0.125f, -0.125f, 0.0f), explosionSpawnLocation + new Vector3(1.5f, -1.5f, 0.0f), 2.0f));
                // yield return StartCoroutine(MoveObjectOverTime(explosionNE.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(-0.125f, -0.125f, 0.0f), explosionSpawnLocation + new Vector3(-1.5f, -1.5f, 0.0f), 2.0f));
                
                // Debug.Log("[Projectile] Instantiating explosion");
                // // -------------------------------- //    
            // }

            yield return null;
        }
        
    }

    void OnTriggerEnter(Collider coll)
    {

        GameObject objectCollidedWith = coll.gameObject;

        if (objectCollidedWith.tag == "rupee" && willReturn && Sender.GetComponent<Inventory>() != null)
        {
            Sender.GetComponent<Inventory>().AddRupees(1);
            Destroy(coll.gameObject);
        }

        if (GetComponent<switchController>() != null && ((coll.gameObject.tag == "heart") || (coll.gameObject.tag == "rupee") || (coll.gameObject.tag == "key")))
            {
                Debug.Log("Setting a switch object");
                switchController.SetHit(coll.gameObject);
                Destroy(gameObject);
            }
    }
}

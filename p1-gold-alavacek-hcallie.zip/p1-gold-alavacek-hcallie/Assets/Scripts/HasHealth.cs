using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class HasHealth : MonoBehaviour
{
    public int maxHealth = 6;
    public bool fullHealth = true;

    //links is 1 for now, mobs should be 0
    public float timeInvincible = 1.0f;
    public bool NPC;

    public System.Action deathCallback;

    public GameObject heartController;
    public GameObject self;


    public int health { get { return currentHealth; } }

    int currentHealth;
    bool isInvincible;
    float invincibleTimer;

    Animator animator;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        currentHealth = maxHealth;
        isInvincible = false;
    }

    // Update is called once per frame
    void Update()
    {

        if (currentHealth <= 0 && deathCallback != null)
        {   //TODO: do we need to reset current health? why is it not taken care of in scene reset for player

            deathCallback();
            currentHealth = maxHealth;
        }

        // hcallie -> set god mode
        if (self.tag == "Player" && self.GetComponent<ArrowKeyMovement>().godMode)
        {
            isInvincible = true;
            invincibleTimer = timeInvincible;
        }

        if (isInvincible)
        {
            invincibleTimer -= Time.deltaTime;
            if (invincibleTimer < 0)
            {
                isInvincible = false;
            }
        }

        if (health == 6) // hcallie
        {
            fullHealth = true;
        }
        else{
            fullHealth = false;
        }
    }

    public void ChangeHealth(int amount, Vector3 knockback)
    {
        if (amount < 0)
        {

            if (isInvincible)
            {
                return;
            }

            isInvincible = true;
            invincibleTimer = timeInvincible;
            //Debug.Log("Health: " + currentHealth + "/" + maxHealth);

            //knockback
            GetComponent<Rigidbody>().velocity = knockback;


            StartCoroutine(KnockCo(GetComponent<Rigidbody>()));

        }
        currentHealth = Mathf.Clamp(currentHealth + amount, 0, maxHealth);

        if (!NPC)
        {
            heartController.GetComponent<UIHealth>().ChangeHearts(amount, currentHealth, false);
        }

    }

    IEnumerator KnockCo(Rigidbody other)
    {
        if (other != null)
        {
            if (self.GetComponent<InputToAnimator>() != null)
            {
                self.GetComponent<InputToAnimator>().IsHit(true);
                GetComponent<ArrowKeyMovement>().hasControl = false;
            }
            else
            {
                StartCoroutine(Flashing());

            }


            yield return new WaitForSeconds(0.5f);
            other.velocity = Vector3.zero;


            if (self.GetComponent<InputToAnimator>() != null)
            {
                GetComponent<ArrowKeyMovement>().hasControl = true;
                self.GetComponent<InputToAnimator>().IsHit(false);
            }

        }
    }

    public void IncreaseMaxHealth(int amount)
    {

        Vector3 none = new Vector3(0, 0, 0);
        //restore health 
        Debug.Log("Prev health: " + maxHealth.ToString());
        ChangeHealth(maxHealth-1, none);

        maxHealth = maxHealth + amount;
        Debug.Log("New health: " + maxHealth.ToString());
        currentHealth = maxHealth;

        heartController.GetComponent<UIHealth>().ChangeHearts(amount, maxHealth, true);
    }

    IEnumerator Flashing()
    {
        Color original = GetComponent<SpriteRenderer>().color;

        for (int i = 0; i < 4; i++)
        {
            GetComponent<SpriteRenderer>().color = new Color(200.0f, 0.0f, 0.0f);
            yield return new WaitForSeconds(0.05f);
            GetComponent<SpriteRenderer>().color = original;
            yield return new WaitForSeconds(0.05f);

        }
    }
}

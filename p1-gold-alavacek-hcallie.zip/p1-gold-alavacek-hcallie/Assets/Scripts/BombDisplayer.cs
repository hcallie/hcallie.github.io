using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BombDisplayer : MonoBehaviour
{
    public Inventory inventory;

    public GameObject x;
    public GameObject digitOne;
    public GameObject digitTwo;

    public Sprite zero;
    public Sprite one;
    public Sprite two;
    public Sprite three;
    public Sprite four;
    public Sprite five;
    public Sprite six;
    public Sprite seven;
    public Sprite eight;
    public Sprite nine;

    int numBombs;

    // Start is called before the first frame update
    void Start()
    {
        x.SetActive(true);
        digitOne.SetActive(true);
        digitTwo.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if ((inventory != null))
        {
            numBombs = inventory.NumBombs();

            Debug.Log("[KeyDisplay] Update called");

            if (numBombs < 10) // digit
            {
                digitTwo.SetActive(false);

                Debug.Log("[KeyDisplay] < 10");

                if (numBombs == 0) { digitOne.gameObject.GetComponent<Image>().sprite = zero; }
                else if (numBombs == 1) { digitOne.gameObject.GetComponent<Image>().sprite = one; }
                else if (numBombs == 2) { digitOne.gameObject.GetComponent<Image>().sprite = two; }
                else if (numBombs == 3) { digitOne.gameObject.GetComponent<Image>().sprite = three; }
                else if (numBombs == 4) { digitOne.gameObject.GetComponent<Image>().sprite = four; }
                else if (numBombs == 5) { digitOne.gameObject.GetComponent<Image>().sprite = five; }
                else if (numBombs == 6) { digitOne.gameObject.GetComponent<Image>().sprite = six; }
                else if (numBombs == 7) { digitOne.gameObject.GetComponent<Image>().sprite = seven; }
                else if (numBombs == 8) { digitOne.gameObject.GetComponent<Image>().sprite = eight; }
                else if (numBombs == 9) { digitOne.gameObject.GetComponent<Image>().sprite = nine; }
            }

            else // if 2 digit number
            {
                digitTwo.SetActive(true);

                int tens = numBombs % 10;
                int remainder = numBombs - (tens * 10);

                if (tens == 0) { digitOne.gameObject.GetComponent<Image>().sprite = zero; }
                else if (tens == 1) { digitOne.gameObject.GetComponent<Image>().sprite = one; }
                else if (tens == 2) { digitOne.gameObject.GetComponent<Image>().sprite = two; }
                else if (tens == 3) { digitOne.gameObject.GetComponent<Image>().sprite = three; }
                else if (tens == 4) { digitOne.gameObject.GetComponent<Image>().sprite = four; }
                else if (tens == 5) { digitOne.gameObject.GetComponent<Image>().sprite = five; }
                else if (tens == 6) { digitOne.gameObject.GetComponent<Image>().sprite = six; }
                else if (tens == 7) { digitOne.gameObject.GetComponent<Image>().sprite = seven; }
                else if (tens == 8) { digitOne.gameObject.GetComponent<Image>().sprite = eight; }
                else if (tens == 9) { digitOne.gameObject.GetComponent<Image>().sprite = nine; }

                if (remainder == 0) { digitTwo.gameObject.GetComponent<Image>().sprite = zero; }
                else if (remainder == 1) { digitTwo.gameObject.GetComponent<Image>().sprite = one; }
                else if (remainder == 2) { digitTwo.gameObject.GetComponent<Image>().sprite = two; }
                else if (remainder == 3) { digitTwo.gameObject.GetComponent<Image>().sprite = three; }
                else if (remainder == 4) { digitTwo.gameObject.GetComponent<Image>().sprite = four; }
                else if (remainder == 5) { digitTwo.gameObject.GetComponent<Image>().sprite = five; }
                else if (remainder == 6) { digitTwo.gameObject.GetComponent<Image>().sprite = six; }
                else if (remainder == 7) { digitTwo.gameObject.GetComponent<Image>().sprite = seven; }
                else if (remainder == 8) { digitTwo.gameObject.GetComponent<Image>().sprite = eight; }
                else if (remainder == 9) { digitTwo.gameObject.GetComponent<Image>().sprite = nine; }

            }
        }
    }
}


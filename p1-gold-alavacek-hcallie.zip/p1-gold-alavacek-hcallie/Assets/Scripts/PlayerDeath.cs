using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerDeath : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        GetComponent<HasHealth>().deathCallback += OnDeath;
    }

    void OnDeath()
    {
        Debug.Log("Rip queen, RESET");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }

    private void OnDestroy()
    {
        GetComponent<HasHealth>().deathCallback -= OnDeath;
    }
}

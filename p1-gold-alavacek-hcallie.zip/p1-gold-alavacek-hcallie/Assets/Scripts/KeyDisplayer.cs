using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class KeyDisplayer : MonoBehaviour
{
    public Inventory inventory;

    public GameObject x;
    public GameObject digitOne;
    public GameObject digitTwo;

    public Sprite zero;
    public Sprite one;
    public Sprite two;
    public Sprite three;
    public Sprite four;
    public Sprite five;
    public Sprite six;
    public Sprite seven;
    public Sprite eight;
    public Sprite nine;

    int numKeys;

    // Start is called before the first frame update
    void Start()
    {
        x.SetActive(true);
        digitOne.SetActive(true);
        digitTwo.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if ((inventory != null))
        {
            numKeys = inventory.NumKeys();

            Debug.Log("[KeyDisplay] Update called");

            if (numKeys < 10) // digit
            {
                digitTwo.SetActive(false);

                Debug.Log("[KeyDisplay] < 10");

                if (numKeys == 0) { digitOne.gameObject.GetComponent<Image>().sprite = zero; }
                else if (numKeys == 1) { digitOne.gameObject.GetComponent<Image>().sprite = one; }
                else if (numKeys == 2) { digitOne.gameObject.GetComponent<Image>().sprite = two; }
                else if (numKeys == 3) { digitOne.gameObject.GetComponent<Image>().sprite = three; }
                else if (numKeys == 4) { digitOne.gameObject.GetComponent<Image>().sprite = four; }
                else if (numKeys == 5) { digitOne.gameObject.GetComponent<Image>().sprite = five; }
                else if (numKeys == 6) { digitOne.gameObject.GetComponent<Image>().sprite = six; }
                else if (numKeys == 7) { digitOne.gameObject.GetComponent<Image>().sprite = seven; }
                else if (numKeys == 8) { digitOne.gameObject.GetComponent<Image>().sprite = eight; }
                else if (numKeys == 9) { digitOne.gameObject.GetComponent<Image>().sprite = nine; }
            }

            else // if 2 digit number
            {
                digitTwo.SetActive(true);

                int tens = numKeys % 10;
                int remainder = numKeys - (tens * 10);

                if (tens == 0) { digitOne.gameObject.GetComponent<Image>().sprite = zero; }
                else if (tens == 1) { digitOne.gameObject.GetComponent<Image>().sprite = one; }
                else if (tens == 2) { digitOne.gameObject.GetComponent<Image>().sprite = two; }
                else if (tens == 3) { digitOne.gameObject.GetComponent<Image>().sprite = three; }
                else if (tens == 4) { digitOne.gameObject.GetComponent<Image>().sprite = four; }
                else if (tens == 5) { digitOne.gameObject.GetComponent<Image>().sprite = five; }
                else if (tens == 6) { digitOne.gameObject.GetComponent<Image>().sprite = six; }
                else if (tens == 7) { digitOne.gameObject.GetComponent<Image>().sprite = seven; }
                else if (tens == 8) { digitOne.gameObject.GetComponent<Image>().sprite = eight; }
                else if (tens == 9) { digitOne.gameObject.GetComponent<Image>().sprite = nine; }

                if (remainder == 0) { digitTwo.gameObject.GetComponent<Image>().sprite = zero; }
                else if (remainder == 1) { digitTwo.gameObject.GetComponent<Image>().sprite = one; }
                else if (remainder == 2) { digitTwo.gameObject.GetComponent<Image>().sprite = two; }
                else if (remainder == 3) { digitTwo.gameObject.GetComponent<Image>().sprite = three; }
                else if (remainder == 4) { digitTwo.gameObject.GetComponent<Image>().sprite = four; }
                else if (remainder == 5) { digitTwo.gameObject.GetComponent<Image>().sprite = five; }
                else if (remainder == 6) { digitTwo.gameObject.GetComponent<Image>().sprite = six; }
                else if (remainder == 7) { digitTwo.gameObject.GetComponent<Image>().sprite = seven; }
                else if (remainder == 8) { digitTwo.gameObject.GetComponent<Image>().sprite = eight; }
                else if (remainder == 9) { digitTwo.gameObject.GetComponent<Image>().sprite = nine; }

            }
        }
    }
}


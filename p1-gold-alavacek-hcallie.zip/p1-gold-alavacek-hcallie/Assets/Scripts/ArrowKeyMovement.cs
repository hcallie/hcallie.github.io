using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowKeyMovement : MonoBehaviour
{
    public float movementSpeed = 4f;
    public bool notMoving;

    public bool godMode = false;
    public bool hasControl = true;

    // Player Components
    Rigidbody rb;
    BoxCollider boxCollider;
    GridMovement adjust;
    Inventory inventory;
    UIWeapon weapon;
    HasHealth health;

    public AudioClip bombAudio;

    public SpriteRenderer spriteRenderer;

    public GameObject[] swords;
    public Vector3 direction;
    private Animator anim;

    public Sprite prevSprite;

    public AudioClip shootLazerSwordAudio;

    Sprite hitUp;
    Sprite hitDown;
    Sprite hitRight;
    Sprite hitLeft;

    bool displayBlockPosition = false;

    Vector3 bombPosition;

    bool laserShooting;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        adjust = GetComponent<GridMovement>();
        inventory = GetComponent<Inventory>();
        boxCollider = GetComponent<BoxCollider>();
        health = GetComponent<HasHealth>();

        weapon = GameObject.Find("WeaponControl").GetComponent<UIWeapon>();

        anim = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        // prevSprite = spriteRenderer.sprite;

        swords[0].gameObject.SetActive(false);
        swords[1].gameObject.SetActive(false);
        swords[2].gameObject.SetActive(false);
        swords[3].gameObject.SetActive(false);

        laserShooting = false;
    }

    public void Update()
    {
        Debug.Log("[ArrowKeyMovement] Update hasControl" + hasControl);

        Debug.Log("laser: " + laserShooting);

        if (hasControl) // if the player has control, use the mouse to control the movement
        {
            Vector2 currentInput = GetInput();
            rb.velocity = (currentInput * movementSpeed);
        }
    }

    public Vector2 GetInput()
    {
        float horizontalInput = Input.GetAxisRaw("Horizontal");
        float verticalInput = Input.GetAxisRaw("Vertical");

        if (Mathf.Abs (horizontalInput) > 0.0f) // If horizontal input, move horizontally (horizontal inut overrides vertical movement)
        {
            verticalInput = 0.0f;
        }

        if ((horizontalInput == 0) && (verticalInput == 0)) // if not moving
        {
            notMoving = true;
            anim.SetBool("notMoving", true);
        }
        else // if moving
        {
            notMoving = false;
            anim.SetBool("notMoving", false);
        }

        // Set last direction facing (so that when you stop moving you know what direction you are facing)
        if (horizontalInput > 0) { direction = new Vector3(1, 0, 0); }
        else if (horizontalInput < 0) { direction = new Vector3(-1, 0, 0); }
        else if (verticalInput > 0) { direction = new Vector3(0, 1, 0); }
        else if (verticalInput < 0) { direction = new Vector3(0, -1, 0); }

        ActivateWeapons();

        /* God Mode Toggle */
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            Debug.Log("[ArrowKeyMovement] GOD MODE TOGGLED");
            godMode = !godMode;
        }

        if (Input.GetKeyDown(KeyCode.Alpha9))
        {
            displayBlockPosition = true;
        }

        adjust.ReadjustGrid(horizontalInput, verticalInput);

        return new Vector2 (horizontalInput, verticalInput);
    }

    /* Use Weapon */
    void ActivateWeapons()
    {
        if (Input.GetKeyDown(KeyCode.X)) // sword
        {
            // anim.SetTrigger("hit with sword");
            Debug.Log("[ArrowKeyMovement] [StrikeSword] Before function call");
            StartCoroutine(StrikeSword());

            Debug.Log("[ArrowKeyMovement] Full health check: " + health.fullHealth + health.health);

            /*
            if (health.fullHealth) // If full health shoot laser sword
            {
                Debug.Log("[ArrowKeyMovement] Full health!");
                StartCoroutine(StrikeLaserSword());
            }*/
        }

        else if (Input.GetKeyDown(KeyCode.Z)) // alt weapon
        {
            Debug.Log("[ArrowKeyMovement] Alt weapon");

            if (weapon.altWeaponNum == 3 && ((inventory.NumBombs() > 0) || (godMode == true))) // bomb
            {
                StartCoroutine(PlaceBomb());
            }

            else if (weapon.altWeaponNum == 2) // boomerang
            {
                StartCoroutine(ThrowBoomerang());
            }

            else if (weapon.altWeaponNum == 1 && ((inventory.GetArrows() > 0) || (godMode == true))) // bow
            {
                StartCoroutine(ShootBow());
            }

            else if (weapon.altWeaponNum == 0) //control rod
            {
                StartCoroutine(ShootRod());

            }
        }
        else if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            //teleport camera and player to custom level
            if (GetComponent<Transform>().position.y >= 1)
            {
                //custom level
                Camera.main.GetComponent<teleportToRoom>().GoToNewRoom(new Vector3(39.5f, -4.5f, 0), new Vector3(39.52f, -4.5f, -10));

            }
            else
            {
                //main scene
                Camera.main.GetComponent<teleportToRoom>().GoToNewRoom(new Vector3(39.5f, 4.5f, 0), new Vector3(39.52f, 6.5f, -10));

               
            }

        }
    }

    IEnumerator PlaceBomb()
    {
        // If go mode or >0 m=bombs
        if (!godMode)
        {
            inventory.UseBomb();
        }

        bombPosition = rb.position + new Vector3 (1.0f, 1.0f, -0.45f); // determine look direction for placing

        GameObject bomb = Instantiate(inventory.bombPrefab, bombPosition, Quaternion.identity);

        // Wait before exploding
        yield return new WaitForSeconds(1.0f);

        Debug.Log("[ArrowKeyMovement] [Bomb] Bombs activated");

        // Destroy(bomb);

        StartCoroutine(BombExplosion(bomb));

        Debug.Log("[ArrowKeyMovement] [Bomb] Bombs deactivated");

        yield break;
    }

    IEnumerator ThrowBoomerang()
    {
        hasControl = false;


        yield return null;
        rb.velocity = Vector3.zero;


        GetComponent<InputToAnimator>().IsShooting(true, direction);

        GameObject boomerang = Instantiate(inventory.boomerangPrefab, rb.position + new Vector3(0.0f, 0.0f, -0.45f) + direction * 1.0f, Quaternion.identity);

        inventory.hasBoomerang = false;

        boomerang.GetComponent<Projectile>().SetSender(this.gameObject);
        //Debug.Log("instantiated");
        //Projectile arrowYeet = arrow.GetComponent<Projectile>();
        //Debug.Log("got component");
        boomerang.GetComponent<Projectile>().Launch(direction, 230);

        yield return new WaitForSeconds(0.7f);

        GetComponent<InputToAnimator>().IsShooting(false);

        hasControl = true;

        yield break;
    }
    
    IEnumerator ShootBow()
    {
        hasControl = false;

        Debug.Log("[ArrowKeyMovement] [ShootBow] Called");

        yield return null;
        rb.velocity = Vector3.zero;

        GetComponent<InputToAnimator>().IsShooting(true, direction);

        GameObject bow = Instantiate(inventory.bowPrefab, rb.position + new Vector3(0.0f, 0.0f, 0.0f) + direction * 0.6f, Quaternion.identity);

        if (direction.x != 0)
        {
            if (direction.x < 0)
            {
                bow.GetComponent<Transform>().Rotate(new Vector3(0, 0, 180));
            }
            else
            {
                bow.GetComponent<Transform>().Rotate(new Vector3(0, 0, 0));
            }
        }
        else
        {
            if (direction.y < 0)
            {
                bow.GetComponent<Transform>().Rotate(new Vector3(0, 0, -90));
            }
            else
            {
                bow.GetComponent<Transform>().Rotate(new Vector3(0, 0, 90));
            }

        }


        if (!godMode)
        {
            inventory.UseArrow();
        }

        GameObject arrow = Instantiate(inventory.arrowPrefab, rb.position + new Vector3 (0.0f, 0.0f, -0.45f) + direction * 1.5f, Quaternion.identity);

        arrow.GetComponent<Projectile>().Launch(direction, 300);

        yield return new WaitForSeconds(0.7f);

        GetComponent<InputToAnimator>().IsShooting(false);

        Destroy(bow);

        hasControl = true;

        yield break;
    }

    IEnumerator StrikeLaserSword()
    {
        yield return new WaitForSeconds(0.3f);

        AudioSource.PlayClipAtPoint(shootLazerSwordAudio, Camera.main.transform.position);



        Debug.Log("[ArrowKeyMovement] [ShootLaserSword] Called");

        yield return null;
        rb.velocity = Vector3.zero;

 //     GetComponent<InputToAnimator>().IsShootingLaserSword(true, direction);

        GameObject laserSword = Instantiate(inventory.laserSwordPrefab, rb.position + new Vector3 (0.0f, 0.0f, -0.45f) + direction * 1.5f, Quaternion.identity);
        Physics.IgnoreCollision(laserSword.GetComponent<BoxCollider>(), rb.gameObject.GetComponent<BoxCollider>());
       // Physics.IgnoreCollision(laserSword.GetComponent<BoxCollider>(), sword.GetComponent<BoxCollider>());

        laserSword.GetComponent<Projectile>().Launch(direction, 300);

        yield return new WaitForSeconds(0.1f);

 //     GetComponent<InputToAnimator>().IsShootingLaserSword(false);



        yield break;
    }

    IEnumerator StrikeSword()
    {
        hasControl = false;
        boxCollider.enabled = false;

        Debug.Log("[ArrowKeyMovement] [Sword] StrikeSword called");

        yield return null;


        rb.velocity = Vector3.zero;

        GetComponent<InputToAnimator>().IsSwingingSword(true, direction);
        Debug.Log("[ArrowKeyMovement] [Sword] Instantiating");

        //NEW
        Vector2 oldPos = new Vector2(GetComponent<RectTransform>().position.x, GetComponent<RectTransform>().position.y);
        GetComponent<RectTransform>().anchoredPosition = new Vector2(GetComponent<RectTransform>().position.x + direction.x * 0.5f, GetComponent<RectTransform>().position.y + direction.y * 0.5f);


        GameObject sword = Instantiate(inventory.swordPrefab, rb.position + new Vector3 (0.0f, 0.0f, -0.45f) + direction * 0.5f, Quaternion.identity);
        Physics.IgnoreCollision(sword.GetComponent<BoxCollider>(), rb.gameObject.GetComponent<BoxCollider>());

        sword.GetComponent<Projectile>().Swing(direction);
        
        if ((health.health == GetComponent<HasHealth>().maxHealth || godMode) && !laserShooting)
        {
            laserShooting = true;
            yield return StartCoroutine(StrikeLaserSword());
        }
        else 
        {
            // yield return new WaitForSeconds(0.8f);
        }

        yield return new WaitForSeconds(0.4f);

        GetComponent<InputToAnimator>().IsSwingingSword(false);

        Destroy(sword);

        boxCollider.enabled = true;


        GetComponent<RectTransform>().anchoredPosition = oldPos;
        hasControl = true;

        laserShooting = false;


        yield break;
    }

    IEnumerator BombExplosion(GameObject bomb)
    {
        // Explodes
        GameObject bombExplosionCollider = Instantiate(inventory.bombExplosionCollider, bombPosition, Quaternion.identity);

        GameObject bombExplosionC = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (0.0f, 0.0f, 0.0f), Quaternion.identity);
        // GameObject bombExplosionN = Instantiate(inventory.bombExplosionThick, bombPosition + new  Vector3 (0.0f, 1.0f, 0.0f), Quaternion.identity);
        GameObject bombExplosionNE = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (0.5f, 1.0f, 0.0f), Quaternion.identity);
        GameObject bombExplosionE = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (1.0f, 0.0f, 0.0f), Quaternion.identity);
        GameObject bombExplosionSE = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (0.5f, -1.0f, 0.0f), Quaternion.identity);
        // GameObject bombExplosionS = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (0.0f, -1.0f, 0.0f), Quaternion.identity);
        GameObject bombExplosionSW = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (-0.5f, -1.0f, 0.0f), Quaternion.identity);
        GameObject bombExplosionW = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (-1.0f, 0.0f, 0.0f), Quaternion.identity);
        GameObject bombExplosionNW = Instantiate(inventory.bombExplosionThick, bombPosition + new Vector3 (-0.5f, 1.0f, 0.0f), Quaternion.identity);

        // Thick (X) and Thin (O)

        yield return new WaitForSeconds(0.125f);

        Destroy(bomb);

        AudioSource.PlayClipAtPoint(bombAudio, Camera.main.transform.position);

        // X O X
        // O X O
        // O X X

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionSW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        yield return new WaitForSeconds(0.125f);

        // X X O
        // 0 X X
        // X 0 X

        bombExplosionNE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        // bombExplosionS.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionSW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;

        yield return new WaitForSeconds(0.125f);

        // X O X
        // X X X
        // X X O

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionSE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        bombExplosionNE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        // bombExplosionS.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;

        yield return new WaitForSeconds(0.125f);

        // X X O
        // O X X
        // X X O

        bombExplosionW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionNE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;

        yield return new WaitForSeconds(0.125f);

        // O X O
        // X O O
        // O O X

        bombExplosionNW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionC.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionSW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        // bombExplosionS.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        bombExplosionNE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionSE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;

        // Second round ----------------------------------------------------------------------------------------------------

        yield return new WaitForSeconds(0.125f);

        // delete NW and S

        Destroy(bombExplosionNW);
        // Destroy(bombExplosionS);

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionSW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        yield return new WaitForSeconds(0.125f);

        // delete SE, W, and NE
        Destroy(bombExplosionSE);
        Destroy(bombExplosionW);
        Destroy(bombExplosionNE);

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionSW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;

        yield return new WaitForSeconds(0.125f);

        // X O X
        // X X X
        // X X O

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionSW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionC.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        yield return new WaitForSeconds(0.125f);

        // X X O
        // O X X
        // X X O

        // bombExplosionN.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;
        bombExplosionE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionC.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThick;

        // Destroy(bombExplosionN);
        Destroy(bombExplosionC);

        yield return new WaitForSeconds(0.125f);

        // O X O
        // X O O
        // O O X

        bombExplosionE.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;
        bombExplosionSW.gameObject.GetComponent<SpriteRenderer>().sprite = inventory.explosionThin;

        yield return new WaitForSeconds(0.1f);

        Destroy(bombExplosionE);
        Destroy(bombExplosionSW);
        Destroy(bombExplosionCollider);
    }


    IEnumerator ShootRod()
    {
        hasControl = false;


        yield return null;
        rb.velocity = Vector3.zero;

        GetComponent<InputToAnimator>().IsShooting(true, direction);

        GameObject controlOrb = Instantiate(inventory.orbPrefab, rb.position + new Vector3(0.0f, 0.0f, -0.45f) + direction * 1.5f, Quaternion.identity);

        GameObject controlRod = Instantiate(inventory.switchRodPrefab, rb.position + new Vector3(0.0f, 0.0f, 0.0f) + direction * 0.8f, Quaternion.identity);

        if (direction.x != 0)
        {
            if (direction.x < 0)
            {
                controlRod.GetComponent<Transform>().Rotate(new Vector3(0, 0, 90));
            }
            else
            {
                controlRod.GetComponent<Transform>().Rotate(new Vector3(0, 0, -90));
            }
        }
        else
        {
            if (direction.y < 0)
            {
                controlRod.GetComponent<Transform>().Rotate(new Vector3(0, 0, 180));
            }
            
        }


        controlOrb.GetComponent<Projectile>().Launch(direction, 100); // 150 -> 100


        yield return new WaitForSeconds(0.3f);

        GetComponent<InputToAnimator>().IsShooting(false);

        hasControl = true;
        Destroy(controlRod);

        yield break;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DespawnWalls : MonoBehaviour
{
    public GameObject wall1;
    public GameObject wall2;
    public GameObject wall3;
    public GameObject wall4;


    // Update is called once per frame
    void OnTriggerEnter(Collider collision)
    {
        if (collision.tag == "Player")
        {
            // yield return new WaitForSeconds(0.1f);

            wall1.SetActive(false);
            wall2.SetActive(false);
            wall3.SetActive(false);
            wall4.SetActive(false);
        }
    }
}

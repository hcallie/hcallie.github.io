using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawnMobs : MonoBehaviour
{

    public GameObject[] Mobs;
    private GameObject[] instantiatedMobs;
    int numEnemies;

    public Vector3[] spawnLocation;

    public bool willDropKey;
    
    bool hasEnteredBefore;
    //bool allMobsDead;

    public GameObject keyToSpawn;
    public Vector3 keySpawnLocation;

    public AudioClip objectSummoned;


    // Start is called before the first frame update
    void Start()
    {
        instantiatedMobs = new GameObject[Mobs.Length];
        //Debug.Log(instantiatedMobs.Length);
        numEnemies = Mobs.Length;


        hasEnteredBefore = false;


    }


    private void OnTriggerEnter(Collider other)
    {
        if (hasEnteredBefore == false)
        {
            StartCoroutine(InitialSpawn());
            Debug.Log("[SpawnMobs] Triggered");
        }
        hasEnteredBefore = true;


    }

    private void Update()
    {
        if (willDropKey && hasEnteredBefore)
        {
            //Debug.Log("Num enemies: " + numEnemies.ToString());

            if (numEnemies == 0)
            {

                //Debug.Log("0 so spawning key");

                GameObject spawnedKey = Instantiate(keyToSpawn);
                spawnedKey.transform.position = keySpawnLocation;
                if (objectSummoned != null)
                {
                
                AudioSource.PlayClipAtPoint(objectSummoned, Camera.main.transform.position);
                }


                spawnedKey.SetActive(true);
                willDropKey = false;
            }
        }
    }

    IEnumerator InitialSpawn()
    {
        yield return new WaitForSeconds(2.5f);
        Debug.Log("[SpawnMobs] Num to spawn = " + Mobs.Length);

        Vector3 position;
        for (int i = 0; i < Mobs.Length; i++)
        {
            position = spawnLocation[i];

            instantiatedMobs[i] = Instantiate(Mobs[i]);

            Debug.Log("[SpawnMobs] Spawning mob " + i);

            //Instantiate(Mobs[i]);

            //Mobs[i].transform.position = position;
            //Mobs[i].gameObject.SetActive(true);

            instantiatedMobs[i].transform.position = position;
            instantiatedMobs[i].gameObject.SetActive(true);

            if (instantiatedMobs[i].GetComponent<MobDeath>() != null)
            {
                instantiatedMobs[i].GetComponent<MobDeath>().SetAssignedRoom(this.gameObject);
            }

            //yield return new WaitForSeconds(3.0f);
        }

        yield return null;
    }

    public void DecrementNumEnemies()
    {
        numEnemies = numEnemies - 1;
    }

}

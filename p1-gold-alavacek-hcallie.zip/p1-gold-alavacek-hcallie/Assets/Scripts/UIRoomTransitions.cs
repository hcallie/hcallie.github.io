using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIRoomTransitions : MonoBehaviour
{
    public GameObject player;
    public GameObject mainCamera;

    public string doorTag;

    public bool performRoomTransition = false;
    public bool notAlreadyTransitioning = true; // hcallie

    void Start()
    {
        StartCoroutine(WaitForRoomTransition());
    }

    IEnumerator WaitForRoomTransition()
    {
        while (true)
        {
            if (performRoomTransition && notAlreadyTransitioning)
            {
                Debug.Log("[Door/Room] [UIRoomTransitions] Triggered a room transition for " + doorTag);
                
                if (doorTag == "NorthDoor" && notAlreadyTransitioning)
                {
                    notAlreadyTransitioning = false;
                    StartCoroutine(PerformRoomTransitionNorth());
                }

                else if (doorTag == "WestDoor" && notAlreadyTransitioning)
                {
                    notAlreadyTransitioning = false;
                    StartCoroutine(PerformRoomTransitionWest());
                }

                else if (doorTag == "EastDoor" && notAlreadyTransitioning)
                {
                    notAlreadyTransitioning = false;
                    StartCoroutine(PerformRoomTransitionEast());
                }

                else if (doorTag == "SouthDoor" && notAlreadyTransitioning)
                {
                    notAlreadyTransitioning = false;
                    StartCoroutine(PerformRoomTransitionSouth());
                }
                
                performRoomTransition = false;
                notAlreadyTransitioning = true;

                Debug.Log("[Door/Room] [UIRoomTransitions] Ready for next transition");
            }

            yield return null;
        }
    }

    IEnumerator PerformRoomTransitionNorth()
    {
        // Disable player controls
        player.GetComponent<ArrowKeyMovement>().hasControl = false;
        player.GetComponent<BoxCollider>().enabled = false;
        player.GetComponent<Rigidbody>().velocity = new Vector2(0.0f, 1.5f);

        // Set positions
        Vector3 initialPosition = transform.position;
        Vector3 finalPosition = new Vector3(initialPosition.x, initialPosition.y + 11, initialPosition.z);

        // Move camera over 2.5 seconds
        yield return StartCoroutine(MoveObjectOverTime(transform, initialPosition, finalPosition, 2.5f));

        // Enable Controls
        player.GetComponent<Rigidbody>().velocity = Vector2.zero;
        player.GetComponent<BoxCollider>().enabled = true;
        player.GetComponent<ArrowKeyMovement>().hasControl = true;

        yield return null;

    }

    IEnumerator PerformRoomTransitionSouth()
    {
        // Disable player controls
        player.GetComponent<ArrowKeyMovement>().hasControl = false;
        player.GetComponent<BoxCollider>().enabled = false;
        player.GetComponent<Rigidbody>().velocity = new Vector2(0.0f, -1.5f);

        // Set positions
        Vector3 initialPosition = transform.position;
        Vector3 finalPosition = new Vector3(initialPosition.x, initialPosition.y - 11, initialPosition.z);

        // Move camera over 2.5 seconds
        yield return StartCoroutine(MoveObjectOverTime(transform, initialPosition, finalPosition, 2.5f));

        // Enable Controls
        player.GetComponent<Rigidbody>().velocity = Vector2.zero;
        player.GetComponent<BoxCollider>().enabled = true;
        player.GetComponent<ArrowKeyMovement>().hasControl = true;

        yield return null;

    }

    IEnumerator PerformRoomTransitionWest()
    {
        // Disable player controls
        player.GetComponent<ArrowKeyMovement>().hasControl = false;
        player.GetComponent<BoxCollider>().enabled = false;
        player.GetComponent<Rigidbody>().velocity = new Vector2(-1.5f, 0f);

        // Set positions
        Vector3 initialPosition = transform.position;
        Vector3 finalPosition = new Vector3(initialPosition.x - 16, initialPosition.y, initialPosition.z);

        // Move camera over 2.5 seconds
        yield return StartCoroutine(MoveObjectOverTime(transform, initialPosition, finalPosition, 2.5f));

        // Enable Controls
        player.GetComponent<Rigidbody>().velocity = Vector2.zero;
        player.GetComponent<BoxCollider>().enabled = true;
        player.GetComponent<ArrowKeyMovement>().hasControl = true;

        yield return null;

    }

      IEnumerator PerformRoomTransitionEast()
    {
        // Disable player controls
        player.GetComponent<ArrowKeyMovement>().hasControl = false;
        player.GetComponent<BoxCollider>().enabled = false;
        player.GetComponent<Rigidbody>().velocity = new Vector2(1.5f, 0f);

        // Set positions
        Vector3 initialPosition = transform.position;
        Vector3 finalPosition = new Vector3(initialPosition.x + 16, initialPosition.y, initialPosition.z);

        // Move camera over 2.5 seconds
        yield return StartCoroutine(MoveObjectOverTime(transform, initialPosition, finalPosition, 2.5f));

        // Enable Controls
        player.GetComponent<Rigidbody>().velocity = Vector2.zero;
        player.GetComponent<BoxCollider>().enabled = true;
        player.GetComponent<ArrowKeyMovement>().hasControl = true;

        yield return null;

    }

    // Moves the camera from a initial position to a final position by "Lerping"
    public static IEnumerator MoveObjectOverTime(Transform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {
        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.position = newPosition;

            yield return null;
        }

        target.position = finalPosition;
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIWeapon : MonoBehaviour
{
    public GameObject player;

    public Image[] inventoryDisplay;
    bool playerInventoryStandardWeapon;
    bool playerInventoryAltWeapon;
    bool playerInventoryWeaponToggle;
    public int altWeaponNum = 0;

    bool hasSword = true;
    bool hasBow = true;
    bool hasBoomerang = true;
    bool hasBomb = true;
    bool hasSwitchRod = true;


    bool godMode = false;

    

    void Start()
    {
        // Players start holding standard weapon
        inventoryDisplay[0].gameObject.SetActive(false);
        inventoryDisplay[1].gameObject.SetActive(false);

        // Show standard and alt weapons as sword and bow
        inventoryDisplay[2].gameObject.SetActive(true); // sword
        inventoryDisplay[3].gameObject.SetActive(true); // bomb
        inventoryDisplay[4].gameObject.SetActive(false); // boomerang
        inventoryDisplay[5].gameObject.SetActive(false); // bow
        inventoryDisplay[6].gameObject.SetActive(false); // switchrod

        inventoryDisplay[7].gameObject.SetActive(true); // A and B


        //start on bomb
        altWeaponNum = 3;
    }

    // Update is called once per frame
    void Update()
    {

        hasSword = player.GetComponent<Inventory>().hasSword;
        hasBow = player.GetComponent<Inventory>().hasBow;
        hasBoomerang = player.GetComponent<Inventory>().hasBoomerang;
        hasBomb = player.GetComponent<Inventory>().hasBomb;
        hasSwitchRod = player.GetComponent<Inventory>().hasSwitchRod;

        godMode = player.GetComponent<ArrowKeyMovement>().godMode;

        // Enable all weapons if godMode activated
        if (godMode)
        {
            hasSword = true;
            hasBow = true;
            hasBoomerang = true;
            hasBomb = true;
            hasSwitchRod = true;
        }

        playerInventoryStandardWeapon = player.GetComponent<Inventory>().holdingStandardWeapon;
        playerInventoryAltWeapon = player.GetComponent<Inventory>().holdingAltWeapon;
        playerInventoryWeaponToggle = player.GetComponent<Inventory>().weaponToggle;

        //  --------- SWITCH BETWEEN HOLDING STANDARD OR ALT --------- //
        // if (playerInventoryStandardWeapon)
        // {
        //     inventoryDisplay[0].gameObject.SetActive(true);
        //     inventoryDisplay[1].gameObject.SetActive(false);
        // }
        // else
        // {
        //     inventoryDisplay[0].gameObject.SetActive(false);
        //     inventoryDisplay[1].gameObject.SetActive(true);
        // }

        // --------------------- SWITCH ALT WEAPON --------------------- //
        bool switched = false;


        while (playerInventoryWeaponToggle && !switched)
        {
            // Switch to Bow
            if (playerInventoryWeaponToggle && (altWeaponNum == 0) && !switched)
            {
                if (hasBow)
                {
                    // Toggle to alt weapon 2
                    inventoryDisplay[3].gameObject.SetActive(false); // bomb
                    inventoryDisplay[4].gameObject.SetActive(false); // boomerang
                    inventoryDisplay[5].gameObject.SetActive(true); // bow
                    switched = true;

                    inventoryDisplay[6].gameObject.SetActive(false); // switch rod
                }


                altWeaponNum++;
            }

            // Switch to Boomerang
            if (playerInventoryWeaponToggle && (altWeaponNum == 1) && !switched)
            {
                if (hasBoomerang)
                {
                    // Toggle to alt weapon 2
                    inventoryDisplay[3].gameObject.SetActive(false); // bomb
                    inventoryDisplay[4].gameObject.SetActive(true); // boomerang
                    inventoryDisplay[5].gameObject.SetActive(false); // bow
                    switched = true;

                    inventoryDisplay[6].gameObject.SetActive(false); // switch rod
                }

                altWeaponNum++;
            }



            //Switch to Bomb
            if (playerInventoryWeaponToggle && (altWeaponNum == 2) && !switched)
            {
                if (hasBomb)
                {
                    // Toggle to alt weapon 2
                    inventoryDisplay[5].gameObject.SetActive(false); // bow
                    inventoryDisplay[4].gameObject.SetActive(false); // boomerang
                    inventoryDisplay[3].gameObject.SetActive(true); // bomb
                    switched = true;

                    inventoryDisplay[6].gameObject.SetActive(false); // switch rod           
                }
                altWeaponNum++;

            }


            //Switch to SwitchRod
            if (playerInventoryWeaponToggle && (altWeaponNum == 3) && !switched)
            {
                if (hasSwitchRod)
                {
                    // Toggle to alt weapon 2
                    inventoryDisplay[5].gameObject.SetActive(false); // bow
                    inventoryDisplay[4].gameObject.SetActive(false); // boomerang
                    inventoryDisplay[3].gameObject.SetActive(false); // bomb
                    switched = true;

                    inventoryDisplay[6].gameObject.SetActive(true); // switch rod
                }
                altWeaponNum = 0;
            }

        }

    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileExplosion : MonoBehaviour
{

    // GameObject explosionNE;
    public GameObject projectileExplosionPrefabNE;
    public GameObject projectileExplosionPrefabNW;
    public GameObject projectileExplosionPrefabSE;
    public GameObject projectileExplosionPrefabSW;

    public Vector3 explosionSpawnLocation;
    public bool explosionTrigger;

    public Sprite noSprite;

    public bool explosionHappening;

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("[ProjectileExplosion] Start called");
        explosionTrigger = false;
        explosionHappening = false;
        // StartCoroutine(ExplosionCoroutine());
    }

    void Update()
    {
        Debug.Log("[ProjectileExplosion]Update");
        if (explosionTrigger)
        {
            Debug.Log("[ProjectileExplosion] explosionTrigger: True");
            CallCoroutine();

            explosionTrigger = false;
        }

        Debug.Log("[ProjectileExplosion] Explosion happening " + explosionHappening);

        // if (!explosionHappening)
        // {
        //     // Destroy all left
        //     if (explosionNE != null) { Destroy(explosionNE); }
        //     if (explosionNW != null) { Destroy(explosionNW); }
        //     if (explosionSE != null) { Destroy(explosionSE); }
        //     if (explosionSW != null) { Destroy(explosionSW); }
        // }
    }

    void CallCoroutine()
    {
        Debug.Log("[ProjectileExplosion] CallCoroutine");

        StartCoroutine(ExplosionCoroutine());
    }

    IEnumerator ExplosionCoroutine()
    {
        //while (true)
        //{
        
        explosionHappening = true;
        Debug.Log("[Projectile] ExplosionCoroutine");

        // ---------- Explosion ----------- //
        GameObject explosionNE = Instantiate(projectileExplosionPrefabNE, explosionSpawnLocation + new Vector3(0.125f, 0.125f, 0.0f), Quaternion.identity);
        GameObject explosionNW = Instantiate(projectileExplosionPrefabNW, explosionSpawnLocation + new Vector3(-0.125f, 0.125f, 0.0f), Quaternion.identity);
        GameObject explosionSE = Instantiate(projectileExplosionPrefabSE, explosionSpawnLocation + new Vector3(0.125f, -0.125f, 0.0f), Quaternion.identity);
        GameObject explosionSW = Instantiate(projectileExplosionPrefabSW, explosionSpawnLocation + new Vector3(-0.125f, -0.125f, 0.0f), Quaternion.identity);

        GetComponent<BoxCollider>().enabled = false;
        
        StartCoroutine(MoveObjectOverTime(explosionNE.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(0.125f, 0.125f, 0.0f), explosionSpawnLocation + new Vector3(1.5f, 1.5f, 0.0f), 0.5f));
        StartCoroutine(MoveObjectOverTime(explosionNW.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(-0.125f, 0.125f, 0.0f), explosionSpawnLocation + new Vector3(-1.5f, 1.5f, 0.0f), 0.5f));
        StartCoroutine(MoveObjectOverTime(explosionSE.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(0.125f, -0.125f, 0.0f), explosionSpawnLocation + new Vector3(1.5f, -1.5f, 0.0f), 0.5f));
        StartCoroutine(MoveObjectOverTime(explosionSW.gameObject.GetComponent<Transform>(), explosionSpawnLocation + new Vector3(-0.125f, -0.125f, 0.0f), explosionSpawnLocation + new Vector3(-1.5f, -1.5f, 0.0f), 0.5f));

        yield return new WaitForSeconds(0.5f);
        
        Debug.Log("[Projectile] Instantiating explosion coroutine [EXP TRIGGER] ------------------------------------------------------------------- ");
        // -------------------------------- //

        Destroy(explosionNE);
        Destroy(explosionNW);
        Destroy(explosionSE);
        Destroy(explosionSW);

        explosionHappening = false;
        Debug.Log("[ProjectileExplosion] Explosion happening (in) " + explosionHappening);

        Destroy(gameObject);

        yield return null;
        //}
        
    }

    public static IEnumerator MoveObjectOverTime(Transform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {

        Debug.Log("[MoveBladeTrap] [Test] before lerp");
        Debug.Log("[MoveBladeTrap] [Test] pos, i: " + initialPosition.x + initialPosition.y + initialPosition.z);
        Debug.Log("[MoveBladeTrap] [Test] pos, f: " + finalPosition.x + finalPosition.y + finalPosition.z);
        
        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.position = newPosition;
            Debug.Log("Sort");

            if (progress >= 1.0f)
            {
                target.gameObject.GetComponent<SpriteRenderer>().sortingOrder = -1; // should make them invisible
                Debug.Log("Sorting order");
            }

            yield return null;
        }

        target.position = finalPosition;
        target.gameObject.GetComponent<SpriteRenderer>().sortingOrder = -1;
        Debug.Log("Sorting order");
    }
}

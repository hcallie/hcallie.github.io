using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageZone : MonoBehaviour
{
    public int damageDone;

    public float thrust;

    public GameObject self;

    public bool isPlayerBoomerang;

    private void OnCollisionEnter(Collision collision)
    {
        //if it has health and we collide then merk that bish
        HasHealth entity = collision.gameObject.GetComponent<HasHealth>();
        string collidedWithName = collision.gameObject.tag;
        //Debug.Log("Got entity: " + entity.tag + " and self:" + self.tag + "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

        if (entity != null && collidedWithName != self.tag && ((!isPlayerBoomerang) || (entity.maxHealth <= 1 && isPlayerBoomerang)))
        {
            Vector3 direction = (collision.transform.position - transform.position).normalized;

            if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            {
                direction.y = 0.0f;
            }
            else
            {
                direction.x = 0.0f;
            }

            Vector3 knockback = direction * thrust;


            //change their health
            entity.ChangeHealth(damageDone, knockback);

        }
    }

 }



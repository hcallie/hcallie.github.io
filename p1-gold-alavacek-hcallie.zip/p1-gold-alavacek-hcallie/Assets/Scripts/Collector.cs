using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Collector : MonoBehaviour
{
    public AudioClip rupeeCollectionSoundClip;

    //hearts, bombs,
    public AudioClip goodPickup;

    public AudioClip keyPickup;

    //fairies, triforce, new weapons
    public AudioClip greatPickup;

    public AudioClip gotTriforce;

    Inventory inventory;

    public GameObject curtainLeft;
    public GameObject curtainRight;

    void Start()
    {
        inventory = GetComponent<Inventory>();
        if (inventory == null)
        {
            Debug.LogWarning("WARNING: Gameobject with a collector has no inventory to store things in!");
            curtainLeft.gameObject.GetComponent<SpriteRenderer>().enabled = false;
            curtainRight.gameObject.GetComponent<SpriteRenderer>().enabled = false;

        }
    }

    void OnTriggerEnter(Collider coll)
    {

        GameObject objectCollidedWith = coll.gameObject;

        if (objectCollidedWith.tag == "rupee")
        {
            if (inventory != null)
            {
                inventory.AddRupees(1);
            }
            Destroy(objectCollidedWith);

            AudioSource.PlayClipAtPoint(rupeeCollectionSoundClip, Camera.main.transform.position);
        }
        else if (objectCollidedWith.tag == "heart")
        {
            //incase we wanna have mobs able to pick stuff up like minecraft lolz
            HasHealth player = GetComponent<HasHealth>();

            if (player != null && !player.NPC)
            {
                if (player.health < player.maxHealth)
                {
                    Vector3 none = new Vector3(0, 0, 0);
                    player.ChangeHealth(2, none);
                }
                Destroy(objectCollidedWith);

                AudioSource.PlayClipAtPoint(goodPickup, Camera.main.transform.position);
            }
        }
        else if (objectCollidedWith.tag == "key")
        {
            if (inventory != null)
            {
                inventory.PickedUpKey();
                Destroy(objectCollidedWith);

                AudioSource.PlayClipAtPoint(keyPickup, Camera.main.transform.position);
            }
        }
        else if (objectCollidedWith.tag == "fairy")
        {
            //incase we wanna have mobs able to pick stuff up like minecraft lolz
            HasHealth player = GetComponent<HasHealth>();

            if (player != null && !player.NPC)
            {
                if (player.health < player.maxHealth)
                {
                    Vector3 none = new Vector3(0, 0, 0);
                    player.ChangeHealth(2, none);
                }
                Destroy(objectCollidedWith);

                AudioSource.PlayClipAtPoint(greatPickup, Camera.main.transform.position);
            }
        }
        else if (objectCollidedWith.tag == "bomb_collectible")
        {
            if (inventory != null)
            {
                inventory.PickedUpBomb();
                Destroy(objectCollidedWith);

                // AudioSource.PlayClipAtPoint(bombPickup, Camera.main.transform.position);
            }
        }
        else if (objectCollidedWith.tag == "heartContainer")
        {
            //incase we wanna have mobs able to pick stuff up like minecraft lolz
            HasHealth player = GetComponent<HasHealth>();
            Debug.Log("Picked up heart container!");
            if (player != null && !player.NPC)
            {
                player.IncreaseMaxHealth(2);

                Destroy(objectCollidedWith);
                //Debug.Log("New health:" + player.health.ToString());
                //AudioSource.PlayClipAtPoint(goodPickup, Camera.main.transform.position);
            }
        }
        //in future, create script for individual pick up, have the animation to be played ready to go give to animator and the actions done in the system actions
        else if (objectCollidedWith.tag == "playSpecialAnimation" || objectCollidedWith.tag == "playOneHandSpecialAnim" || objectCollidedWith.tag == "boomerang")
        {
            //Debug.Log("TRIFORCE SLAY");
            AudioSource.PlayClipAtPoint(greatPickup, Camera.main.transform.position);

            if (objectCollidedWith.tag == "playSpecialAnimation" || objectCollidedWith.tag == "playOneHandSpecialAnim")
            {
                StartCoroutine(HoldingAnimation(objectCollidedWith));

            }
            else
            {
                Destroy(objectCollidedWith);
            }


            if (objectCollidedWith.tag == "boomerang")
            {
                inventory.hasBoomerang = true;
            }
            else if (objectCollidedWith.name == "BowPickup")
            {
                inventory.hasBow = true;
                Debug.Log("got bow");
            }
            else if (objectCollidedWith.name.Equals("MagicRodPickup"))
            {
                inventory.hasSwitchRod = true;
            }

        }
    }

    IEnumerator HoldingAnimation(GameObject objectCollidedWith)
    {
        GetComponent<ArrowKeyMovement>().hasControl = false;
        yield return null;
        GetComponent<Rigidbody>().velocity = Vector3.zero;

        //Debug.Log(objectCollidedWith.name);


        if (objectCollidedWith.tag == "playSpecialAnimation")
        {
            objectCollidedWith.GetComponent<Transform>().position = GetComponent<Transform>().position + new Vector3(0, 1, 0);
            GetComponent<InputToAnimator>().IsTwoHandHoldingItem(true);

            Debug.Log("[Collector] Holding Animation");

            // Flash

            gameObject.GetComponent<SpriteRenderer>().sortingOrder = 5;

            curtainLeft.gameObject.GetComponent<SpriteRenderer>().sortingOrder = 4;
            curtainRight.gameObject.GetComponent<SpriteRenderer>().sortingOrder = 4;

            StartCoroutine(MoveObjectOverTime(curtainLeft.gameObject.GetComponent<Transform>(), curtainLeft.gameObject.GetComponent<Transform>().position, curtainLeft.gameObject.GetComponent<Transform>().position + new Vector3(20f, 0f, 0f), 4.0f));
            StartCoroutine(MoveObjectOverTime(curtainRight.gameObject.GetComponent<Transform>(), curtainRight.gameObject.GetComponent<Transform>().position, curtainRight.gameObject.GetComponent<Transform>().position + new Vector3(-20f, 0f, 0f), 4.0f));
            
        }
        else if (objectCollidedWith.tag == "playOneHandSpecialAnim")
        {
            /*
            if (objectCollidedWith.name == "BoomerangPickup")
            {
                objectCollidedWith.GetComponent<Transform>().position = GetComponent<Transform>().position + new Vector3(-0.3f, 0.8f, 0);
                inventory.hasBoomerang = true;
            }
            else //is bow
            {
                objectCollidedWith.GetComponent<Transform>().position = GetComponent<Transform>().position + new Vector3(-0.3f, 1.0f, 0);
                inventory.hasBow = true;
            }*/

            objectCollidedWith.GetComponent<Transform>().position = GetComponent<Transform>().position + new Vector3(-0.3f, 1.0f, 0);

            GetComponent<InputToAnimator>().IsHoldingNewItem(true);
        }


        yield return new WaitForSeconds(2.0f); // 1.2 -> 4, i think thats a little long i change it to 2.0

        Destroy(objectCollidedWith);

        if (objectCollidedWith.tag == "playSpecialAnimation")
        {
            //GetComponent<InputToAnimator>().IsTwoHandHoldingItem(false);
            AudioSource.PlayClipAtPoint(greatPickup, Camera.main.transform.position);
            StartCoroutine(FinalScene());



        }
        else
        {
            GetComponent<InputToAnimator>().IsHoldingNewItem(false);
            GetComponent<ArrowKeyMovement>().hasControl = true;
        }

    }

    IEnumerator FinalScene()
    {


        yield return new WaitForSeconds(1.0f); // 7 -> 1
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }

    public static IEnumerator MoveObjectOverTime(Transform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {

        // StartCoroutine(MoveObjectOverTime(bladeTrap2.gameObject.GetComponent<Transform>(), initialPosition, finalPosition, 0.5f));

        Debug.Log("[MoveBladeTrap] [Test] before lerp");
        Debug.Log("[MoveBladeTrap] [Test] pos, i: " + initialPosition.x + initialPosition.y + initialPosition.z);
        Debug.Log("[MoveBladeTrap] [Test] pos, f: " + finalPosition.x + finalPosition.y + finalPosition.z);
        
        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.position = newPosition;

            yield return null;
        }

        target.position = finalPosition;
    }

}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PushBlock : MonoBehaviour
{
    public GameObject specialDoorToOpen;
    public Sprite openDoorSprite;
    public Sprite closedDoorSprite;

    public AudioClip figuredSomethingOut;

    public Inventory inventory;

    Transform block;
    float scalar = 0.1f;
    bool displayBlockPosition = false;

    Vector3 triggerPositionOMR = new Vector3(22.0f, 38.0f, 0.0f);
    Vector3 triggerPositionBR = new Vector3(22.0f, 61.0f, 0.0f);
    Vector3 blockPotentialHeight;

    bool alreadyInSpotOMR = false;
    bool alreadyInSpotBR = false;

    void Start()
    {
        block = GetComponent<Transform>();
    }

    void Update()
    {

        if ( (block.gameObject.tag == "pushblock_oldmanroom") && block.position == triggerPositionOMR)
        {
            Debug.Log("[PushBlock] Old Man Room Unlocked");
            specialDoorToOpen.GetComponent<SpriteRenderer>().sprite = openDoorSprite;
            // inventory.hasOldManKey = true;

            specialDoorToOpen.GetComponent<BoxCollider>().enabled = false; // effectively open door
            // AudioSource.PlayClipAtPoint(figuredSomethingOut, Camera.main.transform.position);

            Debug.Log("[PushBlock] Bow Unlocked");
            
            if (!alreadyInSpotOMR)
            {
                AudioSource.PlayClipAtPoint(figuredSomethingOut, Camera.main.transform.position);
                alreadyInSpotOMR = true;
            }
        }
        else
        {
            specialDoorToOpen.GetComponent<SpriteRenderer>().sprite = closedDoorSprite;
            specialDoorToOpen.GetComponent<BoxCollider>().enabled = true; // effectively open door

            alreadyInSpotOMR = false;
        }

        if ((block.gameObject.tag == "pushblock_bowroom") && block.position == triggerPositionBR)
        {
            Debug.Log("[PushBlock] Bow Unlocked");

            if (!alreadyInSpotBR)
            {
                AudioSource.PlayClipAtPoint(figuredSomethingOut, Camera.main.transform.position);
                alreadyInSpotBR = true;
            }
        }
        else
        {
            alreadyInSpotBR = false;
        }

        Debug.Log("[PushBlock] Position of block = " + block.position.x + " " + block.position.y);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Player") // When something collides with the block, check if it is the player (only players can push blocks)
        {
            // if moving in y or in old man room
            if ((collision.gameObject.GetComponent<ArrowKeyMovement>().direction.x == 0) || (block.gameObject.tag == "pushblock_oldmanroom")) // going up or down, can push (bow room) OR can push any direction (old man room)
            {    
                Debug.Log("[PushBlock] [UpDown] (enter) Either old man room or direction.x is " + collision.gameObject.GetComponent<ArrowKeyMovement>().direction.x);

                // Only allow (bow room) pushblock to be moved one block downwards
                if ((collision.gameObject.GetComponent<ArrowKeyMovement>().direction.x == 0) && (block.gameObject.tag == "pushblock_bowroom")) // going up or down, can push (bow room) OR can push any direction (old man room)
                {
                    // originally at 22, 60

                    blockPotentialHeight = block.position + collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar;

                    if ((blockPotentialHeight.y < 61) && (blockPotentialHeight.y > 60))
                    {
                        Debug.Log("[PushBlock] Block position BR");
                        block.position = block.position + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar);
                    }
                }
                else if ((collision.gameObject.GetComponent<ArrowKeyMovement>().direction.y == 0) && (block.gameObject.tag == "pushblock_oldmanroom")) // oldman room
                {
                    // originally 23, 38

                    blockPotentialHeight = block.position + collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar;

                    if ((blockPotentialHeight.x > 22) && (blockPotentialHeight.x < 23))
                    {
                        Debug.Log("[PushBlock] Block position OMR");
                        block.position = block.position + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar);
                    }
                }
                // else if (!(block.gameObject.tag == "pushblock_oldmanroom") && !(block.gameObject.tag == "pushblock_oldmanroom"))
                // {
                //     Debug.Log("[PushBlock] Block position DEFAULT" + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction.y == 0) + " " + (block.gameObject.tag == "pushblock_oldmanroom"));
                //     block.position = block.position + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar);
                // }
            }
        }
    }

    void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.name == "Player") // When something collides with the block, check if it is the player (only players can push blocks)
        {
            // if moving in y or in old man room
            if ((collision.gameObject.GetComponent<ArrowKeyMovement>().direction.x == 0) || (block.gameObject.tag == "pushblock_oldmanroom")) // going up or down, can push (bow room) OR can push any direction (old man room)
            {    
                Debug.Log("[PushBlock] [UpDown] (enter) Either old man room or direction.x is " + collision.gameObject.GetComponent<ArrowKeyMovement>().direction.x);

                // Only allow (bow room) pushblock to be moved one block downwards
                if ((collision.gameObject.GetComponent<ArrowKeyMovement>().direction.x == 0) && (block.gameObject.tag == "pushblock_bowroom")) // going up or down, can push (bow room) OR can push any direction (old man room)
                {
                    // originally at 22, 60

                    blockPotentialHeight = block.position + collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar;

                    if ((blockPotentialHeight.y < 61) && (blockPotentialHeight.y > 60))
                    {
                        Debug.Log("[PushBlock] Block position BR");
                        block.position = block.position + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar);
                    }
                }
                else if ((collision.gameObject.GetComponent<ArrowKeyMovement>().direction.y == 0) && (block.gameObject.tag == "pushblock_oldmanroom")) // oldman room
                {
                    // originally 23, 38

                    blockPotentialHeight = block.position + collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar;

                    if ((blockPotentialHeight.x > 22) && (blockPotentialHeight.x < 23))
                    {
                        Debug.Log("[PushBlock] Block position OMR");
                        block.position = block.position + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar);
                    }
                    else if (blockPotentialHeight.x > 23)
                    {
                        block.position = new Vector3(23.0f, 38.0f, 0.0f);
                    }
                    else if (blockPotentialHeight.x < 22)
                    {
                        block.position = new Vector3(22.0f, 38.0f, 0.0f);
                    }
                }
                // else if (!(block.gameObject.tag == "pushblock_oldmanroom") && !(block.gameObject.tag == "pushblock_oldmanroom"))
                // {
                //     Debug.Log("[PushBlock] Block position DEFAULT" + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction.y == 0) + " " + (block.gameObject.tag == "pushblock_oldmanroom"));
                //     block.position = block.position + (collision.gameObject.GetComponent<ArrowKeyMovement>().direction * scalar);
                // }
            }
        }
    }

    void OnCollisionExit(Collision collision)
    {
        // When something collides with the block, check if it is the player (only players can push blocks)
        if (collision.gameObject.name == "Player")
        {
            // block.velocity = Vector3.zero;
        }
    }

}

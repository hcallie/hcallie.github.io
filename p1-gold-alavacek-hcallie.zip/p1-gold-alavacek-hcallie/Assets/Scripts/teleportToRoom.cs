using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class teleportToRoom : MonoBehaviour
{
    public Vector3 teleportTo;
    public Vector3 teleportCameraTo;

    public Image blackScreen;
    public GameObject player;
    public GameObject mainCamera;

    public GameObject pushBlock;
        
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            StartCoroutine(FadeAndTeleport());
        }
    }

    IEnumerator FadeAndTeleport()
    {
        float fadeOutAmount = 0.0f;
        Color newColor = blackScreen.GetComponent<Image>().color;

        while (blackScreen.GetComponent<Image>().color.a < 1)
        {
            fadeOutAmount = blackScreen.GetComponent<Image>().color.a + (5.0f * Time.deltaTime);
            newColor = new Color(blackScreen.GetComponent<Image>().color.r, blackScreen.GetComponent<Image>().color.g, blackScreen.GetComponent<Image>().color.b, fadeOutAmount);
            blackScreen.GetComponent<Image>().color = newColor;

            yield return new WaitForSeconds(0.025f);
        }

        player.GetComponent<Transform>().position = teleportTo;
        mainCamera.GetComponent<Transform>().position = teleportCameraTo;

        // tp pushblock back to original spot (22, 60)
        if (pushBlock != null)
        {
            pushBlock.GetComponent<Transform>().position = new Vector3(22.0f, 60.0f, 0.0f);
        }


        while (blackScreen.GetComponent<Image>().color.a > 0)
        {
            fadeOutAmount = blackScreen.GetComponent<Image>().color.a - (5.0f * Time.deltaTime);
            newColor = new Color(blackScreen.GetComponent<Image>().color.r, blackScreen.GetComponent<Image>().color.g, blackScreen.GetComponent<Image>().color.b, fadeOutAmount);
            blackScreen.GetComponent<Image>().color = newColor;

            yield return new WaitForSeconds(0.025f);
        }


        yield break;
    }

    public void GoToNewRoom(Vector3 teleportToIn, Vector3 teleportCameraToIn)
    {
        teleportTo = teleportToIn;
        teleportCameraTo = teleportCameraToIn;

        StartCoroutine(FadeAndTeleport());
    }
}

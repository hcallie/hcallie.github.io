using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridMovement : MonoBehaviour
{
    bool onHorizontalGrid;
    bool onVerticalGrid;

    //public bool isFlying;
    public float gridSize;

    void Start()
    {
        onHorizontalGrid = true;
        onVerticalGrid = true;
    }

    public void ReadjustGrid(float horizontalInput, float verticalInput)
    {
        if (onHorizontalGrid && Mathf.Abs(verticalInput) > 0.0f)
        {
            float determineSnap = (float)(Mathf.Abs(transform.position.x) % gridSize);


            //Debug.Log(determineSnap.ToString());
            float snappedPosition;

            if (determineSnap > (gridSize/2))
            {
                snappedPosition = gridSize - determineSnap;
            }
            else if(determineSnap < -(gridSize/2))
            {
                snappedPosition = -(gridSize) + determineSnap;
            }
            else
            {
                snappedPosition = -determineSnap;
            }


            transform.position = transform.position + new Vector3(snappedPosition, 0, 0);

            onVerticalGrid = true;
            onHorizontalGrid = false;
        }

        else if (onVerticalGrid && Mathf.Abs(horizontalInput) > 0.0f)
        {
            float determineSnap = (float)(Mathf.Abs(transform.position.y) % gridSize);
            //Debug.Log(determineSnap.ToString());
            float snappedPosition;

            if (determineSnap > gridSize/2)
            {
                snappedPosition = gridSize - determineSnap;
            }
            else if (determineSnap < -(gridSize/2))
            {
                snappedPosition = -(gridSize) + determineSnap;
            }
            else
            {
                snappedPosition = -determineSnap;
            }


            transform.position = transform.position + new Vector3(0, snappedPosition, 0);

            onHorizontalGrid = true;
            onVerticalGrid = false;
        }
    }
}

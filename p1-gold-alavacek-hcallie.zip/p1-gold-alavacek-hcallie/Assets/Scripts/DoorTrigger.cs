using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorTrigger : MonoBehaviour
{

    public GameObject mainCamera;
    public GameObject door;

    public bool notAlreadyTransitioning = true;

    // TODO, trigger called and then last enemy dies, make sure that trigger is re-triggered
    private void OnTriggerEnter(Collider other)
    {
        notAlreadyTransitioning = mainCamera.GetComponent<UIRoomTransitions>().notAlreadyTransitioning;

        Debug.Log("[Door/Room] [DoorTrigger] Trigger function called");

        if (other.tag == "Player" && notAlreadyTransitioning)
        {
            Debug.Log("[Door/Room] [DoorTrigger] Transition");
            mainCamera.GetComponent<UIRoomTransitions>().doorTag = door.tag;
            mainCamera.GetComponent<UIRoomTransitions>().performRoomTransition = true;
        }
    }
}
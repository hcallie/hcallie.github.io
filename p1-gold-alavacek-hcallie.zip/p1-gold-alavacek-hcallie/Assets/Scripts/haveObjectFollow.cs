using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class haveObjectFollow : MonoBehaviour
{

    public GameObject objectToFollow;

    // Start is called before the first frame update
    void Start()
    {
        if (objectToFollow.name != "NothingDrop")
        {
            GameObject existingObject = Instantiate(objectToFollow);
            existingObject.GetComponent<Transform>().position = GetComponent<Transform>().position;
            objectToFollow = existingObject;
        }

    }

    // Update is called once per frame
    void Update()
    {
        objectToFollow.GetComponent<Transform>().position = GetComponent<Transform>().position;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnWalls : MonoBehaviour
{
    public GameObject wall1;
    public GameObject wall2;
    public GameObject wall3;
    public GameObject wall4;

    // Update is called once per frame
    void OnTriggerEnter(Collider collision)
    {
        if (collision.tag == "Player")
        {
            // yield return new WaitForSeconds(0.1f);

            wall1.SetActive(true);
            wall2.SetActive(true);
            wall3.SetActive(true);
            wall4.SetActive(true);
        }
    }
}

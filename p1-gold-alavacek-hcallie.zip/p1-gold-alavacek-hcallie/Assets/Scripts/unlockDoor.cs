using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class unlockDoor : MonoBehaviour
{
    public Sprite lockedNR;
    public Sprite lockedNL;
    public Sprite unlockedNR;
    public Sprite unlockedNL;

    public Sprite lockedW;
    public Sprite unlockedW;

    public Sprite lockedE;
    public Sprite unlockedE;

    public GameObject nextTo;

    public AudioClip unlockDoorAudio;

    private void OnCollisionEnter(Collision collision)
    {

        Inventory playerInventory = collision.gameObject.GetComponent<Inventory>();

 //     Debug.Log("Num keys : " + playerInventory.NumKeys());

        if (playerInventory != null)
        {
            Debug.Log("[unlockDoor] godMode = " + collision.gameObject.GetComponent<ArrowKeyMovement>().godMode);

            if ((playerInventory.NumKeys() > 0 && (GetComponent<SpriteRenderer>().sprite != unlockedNR && GetComponent<SpriteRenderer>().sprite != unlockedNL))                 
                || collision.gameObject.GetComponent<ArrowKeyMovement>().godMode)
            {
                if (!collision.gameObject.GetComponent<ArrowKeyMovement>().godMode) { playerInventory.UseKey(); }
                
                // North (use t_081, t_080, t_093, and t_092)
                if((GetComponent<SpriteRenderer>().sprite == lockedNR) || (GetComponent<SpriteRenderer>().sprite == lockedNL))
                {
                    if (GetComponent<SpriteRenderer>().sprite == lockedNR)
                    {
                        GetComponent<SpriteRenderer>().sprite = unlockedNR;
                        nextTo.GetComponent<SpriteRenderer>().sprite = unlockedNL;
                    }
                    else
                    {
                        GetComponent<SpriteRenderer>().sprite = unlockedNL;
                        nextTo.GetComponent<SpriteRenderer>().sprite = unlockedNR;
                    }

                    GetComponent<BoxCollider>().isTrigger = true;
                    nextTo.GetComponent<BoxCollider>().isTrigger = true;
                }

                // West (use t_100 and t_051, for special locked use t_094)
                else if (GetComponent<SpriteRenderer>().sprite == lockedW)
                {
                    GetComponent<SpriteRenderer>().sprite = unlockedW;
                    GetComponent<BoxCollider>().isTrigger = true;
                }

                // East (use t_095 and t_048, for special locked use t_094)
                else if (GetComponent<SpriteRenderer>().sprite == lockedE)
                {
                    GetComponent<SpriteRenderer>().sprite = unlockedE;
                    GetComponent<BoxCollider>().isTrigger = true;
                }

                AudioSource.PlayClipAtPoint(unlockDoorAudio, Camera.main.transform.position);
            }
        }

 //     Debug.Log("Num keys : " + playerInventory.NumKeys());
    }
}
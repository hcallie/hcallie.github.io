using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHealth : MonoBehaviour
{
    public GameObject player;

    public Sprite wholeHeart;
    public Sprite halfHeart;
    public Sprite emptyHeart;
    public Image[] hearts;

    int previousCurrentHealth;

    //public GameObject parentCanvas;

    //private GameObject[] heartContainer;

    int healthCapacity;
    int currentHealth;

    void Start()
    {
        healthCapacity = player.GetComponent<HasHealth>().maxHealth;
        previousCurrentHealth = healthCapacity;

        Debug.Log(hearts.Length.ToString());
        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < (healthCapacity / 2))
            {
                hearts[i].gameObject.SetActive(true);
            }
            else
            {
                hearts[i].gameObject.SetActive(false);
            }
        }
    }

    private void Update()
    {
        //for when we implement heart containers
        healthCapacity = player.GetComponent<HasHealth>().maxHealth;
    }

    public void ChangeHearts(int amount, int currentHealth, bool increaseCapacity)
    {   
        if (!increaseCapacity)
        {
            while (previousCurrentHealth != currentHealth)
            {

                if (amount < 0)
                {
                    previousCurrentHealth--;

                    if (previousCurrentHealth % 2 == 0)
                    {
                        hearts[(int)(previousCurrentHealth / 2)].sprite = emptyHeart;
                        Debug.Log("Health: " + previousCurrentHealth + "/" + healthCapacity);
                    }
                    else
                    {
                        hearts[(int)(previousCurrentHealth / 2)].sprite = halfHeart;
                        Debug.Log("Health: " + previousCurrentHealth + "/" + healthCapacity);
                    }
                }
                else if (healthCapacity > previousCurrentHealth)
                {


                    if (previousCurrentHealth % 2 == 0)
                    {
                        hearts[(int)(previousCurrentHealth / 2)].sprite = halfHeart;
                        //hearts[(int)(previousCurrentHealth / 2)].gameObject.SetActive(true);
                        Debug.Log("Health: " + previousCurrentHealth + "/" + healthCapacity);
                    }
                    else
                    {
                        hearts[(int)(previousCurrentHealth / 2)].sprite = wholeHeart;
                        Debug.Log("Health: " + previousCurrentHealth + "/" + healthCapacity);
                    }
                    previousCurrentHealth++;
                }
            }
        }
        else
        {
            hearts[(int)(previousCurrentHealth / 2)].sprite = wholeHeart;
            hearts[(int)(previousCurrentHealth / 2)].gameObject.SetActive(true);
            previousCurrentHealth = player.GetComponent<HasHealth>().maxHealth;
        }
        
    }

}

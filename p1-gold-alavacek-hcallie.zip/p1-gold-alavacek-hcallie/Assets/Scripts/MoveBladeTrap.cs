using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveBladeTrap : MonoBehaviour
{
    /*
    public Rigidbody bladeTrap1;
    public Rigidbody bladeTrap2;
    
    bool bladeTrapTrigger1 = false;
    bool bladeTrapTrigger2 = false; //
    */
    public Vector3 startDirection;
    Vector3 directionMoving;

    Vector3 north;
    Vector3 east;
    Vector3 south;
    Vector3 west;

    public bool isMoving;



    void Start()
    {
        north = new Vector3(0, 1, 0);
        east = new Vector3(1, 0, 0);
        south = new Vector3(0, -1, 0);
        west = new Vector3(-1, 0, 0);
        /*
        string horizontalOrVertical = gameObject.tag;

        if (horizontalOrVertical == "horizontal_trigger" && ((gameObject.tag == "BladeTrapNW") || (gameObject.tag == "BladeTrapSW"))) { directionMoving = east;  } // go right
        else if (horizontalOrVertical == "horizontal_trigger" && ((gameObject.tag == "BladeTrapNE") || (gameObject.tag == "BladeTrapSE"))) { directionMoving = west; } // go left
        else if (horizontalOrVertical == "vertical_trigger" && ((gameObject.tag == "BladeTrapNW") || (gameObject.tag == "BladeTrapNE"))) { directionMoving = south; } // go down
        else if (horizontalOrVertical == "vertical_trigger" && ((gameObject.tag == "BladeTrapSW") || (gameObject.tag == "BladeTrapSE"))) { directionMoving = north; } // go up
        */
        if (startDirection != new Vector3(0, 0, 0))
        {
            directionMoving = startDirection;
            isMoving = true;
            StartCoroutine(BladeTrapTriggered());
        }

        //StartCoroutine(SecondBladeTrapTriggered());


    }

    private void Update()
    {
        RaycastHit hit;
        
        if (!isMoving)
        {
            //Physics.Raycast(transform.position, north * 2.5f, out hit);
            //Debug.Log("COLLIDER:" + hit.collider.tag);
            if (Physics.Raycast(transform.position, north * 2.5f, out hit) && hit.collider.tag == "Player")
            {
                Debug.Log("triggered north");
                directionMoving = north;
                isMoving = true;
                StartCoroutine(BladeTrapTriggered());
            }
            else if (Physics.Raycast(transform.position, east * 5.0f, out hit) && hit.collider.tag == "Player")
            {
                directionMoving = east;
                isMoving = true;
                StartCoroutine(BladeTrapTriggered());
            }
            else if (Physics.Raycast(transform.position, south * 2.5f, out hit) && hit.collider.tag == "Player")
            {
                Debug.Log("triggered south");
                directionMoving = south;
                isMoving = true;
                StartCoroutine(BladeTrapTriggered());
            }
            else if (Physics.Raycast(transform.position, west * 5.0f, out hit) && hit.collider.tag == "Player")
            {
                directionMoving = west;
                isMoving = true;
                StartCoroutine(BladeTrapTriggered());
            }
        }
 

    }
    /*
    private void OnTriggerEnter(Collider collider)
    {
        // Debug.Log("[MoveBladeTrap] Trigger called");

        // if ((collider.tag != "BladeTrap") && !bladeTrapIsMoving) {
        // if ((collider.tag != "BladeTrap") && (!(bladeTrap1.gameObject.GetComponent<BladeTrapInfo>().isMoving) || (bladeTrap2.gameObject.GetComponent<BladeTrapInfo>().isMoving))) {
        if ((collider.tag != "BladeTrapNW" && collider.tag != "BladeTrapSW" && collider.tag != "BladeTrapNE" && collider.tag != "BladeTrapSE") && (!(bladeTrap1.gameObject.GetComponent<BladeTrapInfo>().isMoving) || (bladeTrap2.gameObject.GetComponent<BladeTrapInfo>().isMoving))) {

            Debug.Log("[MoveBladeTrap] Coroutine called, collider = " + collider.tag);

            if (!(bladeTrap1.gameObject.GetComponent<BladeTrapInfo>().isMoving))
            {
                Debug.Log("[MoveBladeTrap] [Test] Calling 1");
                bladeTrap1.gameObject.GetComponent<BladeTrapInfo>().isMoving = true; // can't be triggered again until coroutine is over
                bladeTrapTrigger1 = true; // trigger the coroutine
            }

            if (!(bladeTrap2.gameObject.GetComponent<BladeTrapInfo>().isMoving))
            {
                Debug.Log("[MoveBladeTrap] [Test] Calling 2");
                bladeTrap2.gameObject.GetComponent<BladeTrapInfo>().isMoving = true; // can't be triggered again until coroutine is over
                bladeTrapTrigger2 = true; // trigger the coroutine
            }
        }
    }*/

    public IEnumerator BladeTrapTriggered()
    {

        /*while (true)
        {
            
            if (bladeTrapTrigger1)
            {
                Debug.Log("[MoveBladeTrap] [Test] In CR 1");
                bladeTrapTrigger1 = false;

                // Set movement direction
                // Debug.Log("[MoveBladeTrap] tag = " + bladeTrap.gameObject.tag);

                float xDiff = 0.0f;
                float yDiff = 0.0f;

                string horizontalOrVertical = gameObject.tag;

                if (horizontalOrVertical == "horizontal_trigger" && ((bladeTrap1.gameObject.tag == "BladeTrapNW") || (bladeTrap1.gameObject.tag == "BladeTrapSW"))) { xDiff = 5.0f; } // go right
                else if (horizontalOrVertical == "horizontal_trigger" && ((bladeTrap1.gameObject.tag == "BladeTrapNE") || (bladeTrap1.gameObject.tag == "BladeTrapSE"))) { xDiff = -5.0f; } // go left
                else if (horizontalOrVertical == "vertical_trigger" && ((bladeTrap1.gameObject.tag == "BladeTrapNW") || (bladeTrap1.gameObject.tag == "BladeTrapNE"))) { yDiff = -2.25f; } // go down
                else if (horizontalOrVertical == "vertical_trigger" && ((bladeTrap1.gameObject.tag == "BladeTrapSW") || (bladeTrap1.gameObject.tag == "BladeTrapSE"))) { yDiff = 2.25f; } // go up

                // Set positions
                Vector3 initialPosition = bladeTrap1.position;
                Vector3 finalPosition = new Vector3(initialPosition.x + xDiff, initialPosition.y + yDiff, initialPosition.z);

                Debug.Log("[MoveBladeTrap] IN COROUTINE");

                // Move bladetrap
                yield return StartCoroutine(MoveObjectOverTime(bladeTrap1.gameObject.GetComponent<Transform>(), initialPosition, finalPosition, 0.5f));
                yield return StartCoroutine(MoveObjectOverTime(bladeTrap1.gameObject.GetComponent<Transform>(), finalPosition, initialPosition, 3.0f));

                bladeTrap1.gameObject.GetComponent<BladeTrapInfo>().isMoving = false;
                
            }

        }*/

        float xDiff = 5.0f * directionMoving.x;
        float yDiff = 2.5f * directionMoving.y;

        Vector3 initialPosition = GetComponent<Transform>().position;
        Vector3 finalPosition = new Vector3(initialPosition.x + xDiff, initialPosition.y + yDiff, initialPosition.z);

        Debug.Log("[MoveBladeTrap] IN COROUTINE");

        // Move bladetrap
        if (isMoving)
        {
            yield return StartCoroutine(MoveObjectOverTime(GetComponent<Transform>(), initialPosition, finalPosition, 0.5f));
        }

        if (isMoving)
        {
            yield return StartCoroutine(MoveObjectOverTime(GetComponent<Transform>(), finalPosition, initialPosition, 3.0f));
        }      


        isMoving = false;



        yield return null;
    } 

    /*
    public IEnumerator SecondBladeTrapTriggered()
    {

        while (true)
        {
            if (bladeTrapTrigger2)
            {
                Debug.Log("[MoveBladeTrap] [Test] In CR 2");
                bladeTrapTrigger2 = false;

                // Set movement direction
                // Debug.Log("[MoveBladeTrap] tag = " + bladeTrap.gameObject.tag);

                float xDiff = 0.0f;
                float yDiff = 0.0f;

                string horizontalOrVertical = gameObject.tag;

                if (horizontalOrVertical == "horizontal_trigger" && ((bladeTrap2.gameObject.tag == "BladeTrapNW") || (bladeTrap2.gameObject.tag == "BladeTrapSW"))) { xDiff = 5.0f; } // go right
                else if (horizontalOrVertical == "horizontal_trigger" && ((bladeTrap2.gameObject.tag == "BladeTrapNE") || (bladeTrap2.gameObject.tag == "BladeTrapSE"))) { xDiff = -5.0f; } // go left
                else if (horizontalOrVertical == "vertical_trigger" && ((bladeTrap2.gameObject.tag == "BladeTrapNW") || (bladeTrap2.gameObject.tag == "BladeTrapNE"))) { yDiff = -2.25f; } // go down
                else if (horizontalOrVertical == "vertical_trigger" && ((bladeTrap2.gameObject.tag == "BladeTrapSW") || (bladeTrap2.gameObject.tag == "BladeTrapSE"))) { yDiff = 2.25f; } // go up

                // Set positions
                Vector3 initialPosition = bladeTrap2.position;
                Vector3 finalPosition = new Vector3(initialPosition.x + xDiff, initialPosition.y + yDiff, initialPosition.z);

                Debug.Log("[MoveBladeTrap] IN COROUTINE");

                // Move bladetrap
                yield return StartCoroutine(MoveObjectOverTime(bladeTrap2.gameObject.GetComponent<Transform>(), initialPosition, finalPosition, 0.5f));
                yield return StartCoroutine(MoveObjectOverTime(bladeTrap2.gameObject.GetComponent<Transform>(), finalPosition, initialPosition, 3.0f));

                bladeTrap2.gameObject.GetComponent<BladeTrapInfo>().isMoving = false;
            }

            yield return null;
        }
    } */

    public IEnumerator MoveObjectOverTime(Transform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {

        Debug.Log("[MoveBladeTrap] [Test] before lerp");
        Debug.Log("[MoveBladeTrap] [Test] pos, i: " + initialPosition.x + initialPosition.y + initialPosition.z);
        Debug.Log("[MoveBladeTrap] [Test] pos, f: " + finalPosition.x + finalPosition.y + finalPosition.z);
        
        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f && isMoving)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.position = newPosition;

            yield return null;
        }

        target.position = finalPosition;
    }
}
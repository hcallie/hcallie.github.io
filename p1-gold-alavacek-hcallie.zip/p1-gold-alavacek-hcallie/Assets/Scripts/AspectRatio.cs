using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AspectRatio : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Screen.SetResolution((Screen.currentResolution.height * (int)((768f/ 720f))/1), Screen.currentResolution.height, true);

    }

}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class switchController : MonoBehaviour
{
    static GameObject firstHit;
    static GameObject secondHit;


    static int hitCount;

    static public void SetHit(GameObject objectHit)
    {

        Debug.Log("[switchController] ");

        if (hitCount == 0)
        {
            firstHit = objectHit;
            hitCount++;
        }
        else if (firstHit != objectHit)
        {
            secondHit = objectHit;
            hitCount = 0;
            DoSwitch();
        }
    }

    static void DoSwitch()
    {
        if (firstHit.GetComponent<MoveBladeTrap>() != null)
        {
            firstHit.GetComponent<MoveBladeTrap>().isMoving = false;
        }
        else if (secondHit.GetComponent<MoveBladeTrap>() != null)
        {
            secondHit.GetComponent<MoveBladeTrap>().isMoving = false;
        }

        Vector3 tempPos = firstHit.GetComponent<Transform>().position;
        //firstHit.GetComponent<Transform>().position = secondHit.GetComponent<Transform>().position;
        //secondHit.GetComponent<Transform>().position = tempPos;
        firstHit.GetComponent<Transform>().position = new Vector3(secondHit.GetComponent<Transform>().position.x, secondHit.GetComponent<Transform>().position.y, firstHit.GetComponent<Transform>().position.z);
        secondHit.GetComponent<Transform>().position = new Vector3(tempPos.x, tempPos.y, secondHit.GetComponent<Transform>().position.z);


        // Vector3 tempPos = firstHit.GetComponent<Transform>().position;

            // firstHit.GetComponent<Transform>().position.x = secondHit.GetComponent<Transform>().position.x;
            // firstHit.GetComponent<Transform>().position.y = secondHit.GetComponent<Transform>().position.y;

            // secondHit.GetComponent<Transform>().position.x = tempPos.x;
            // secondHit.GetComponent<Transform>().position.y = tempPos.y;
    }
}

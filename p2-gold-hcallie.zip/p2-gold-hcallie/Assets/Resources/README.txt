# Retro Texture Pack

Hey, thanks so much for trying out my retro-style texture pack. I started
creating these to make a retro styled FPS, inspired by games like DOOM and Quake,
but it was taking too much time away from my main project, so I decided to
release them as a free texture pack instead.

## Contents

There is currently a total of *220* unique textures, though there are a lot of
variants, so some of the textures are similar.

## License

See the LICENSE.txt file included in this asset pack for full details, but in
short you're welcome to use the texture in any non-commercial and commercial
works. You may not, however, distribute the texture pack in any format.

## Contact

If you encounter any problems, have any questions or have some feedback,
you can reach me here:

- Twitter: https://twitter.com/MartiansGame
- Discord: https://discord.gg/bmwsKU6dqP
- Website: https://little-martian.dev
- Mail: craig@craigsmith.info

Thank you!
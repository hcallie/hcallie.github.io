using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UILevelController : MonoBehaviour
{
    public ObjectInfo player_info;

    public Image level_counter_tens;
    public Image level_counter_ones;

    public Sprite zero;
    public Sprite one;
    public Sprite two;
    public Sprite three;
    public Sprite four;
    public Sprite five;
    public Sprite six;
    public Sprite seven;
    public Sprite eight;
    public Sprite nine;

    int level;

    void Update()
    {

        // ---------------- LEVEL UI ---------------- //

        level = player_info.level;

        if (level < 10) // digit
        {
            level_counter_tens.sprite = zero;

            if (level == 0) { level_counter_ones.sprite = zero; }
            else if (level == 1) { level_counter_ones.sprite = one; }
            else if (level == 2) { level_counter_ones.sprite = two; }
            else if (level == 3) { level_counter_ones.sprite = three; }
            else if (level == 4) { level_counter_ones.sprite = four; }
            else if (level == 5) { level_counter_ones.sprite = five; }
            else if (level == 6) { level_counter_ones.sprite = six; }
            else if (level == 7) { level_counter_ones.sprite = seven; }
            else if (level == 8) { level_counter_ones.sprite = eight; }
            else if (level == 9) { level_counter_ones.sprite = nine; }
        }

        else // if 2 digit number
        {
            int tens = level % 10;
            int remainder = level - (tens * 10);

            if (tens == 0) { level_counter_tens.sprite = zero; }
            else if (tens == 1) { level_counter_tens.sprite = one; }
            else if (tens == 2) { level_counter_tens.sprite = two; }
            else if (tens == 3) { level_counter_tens.sprite = three; }
            else if (tens == 4) { level_counter_tens.sprite = four; }
            else if (tens == 5) { level_counter_tens.sprite = five; }
            else if (tens == 6) { level_counter_tens.sprite = six; }
            else if (tens == 7) { level_counter_tens.sprite = seven; }
            else if (tens == 8) { level_counter_tens.sprite = eight; }
            else if (tens == 9) { level_counter_tens.sprite = nine; }

            if (remainder == 0) { level_counter_ones.sprite = zero; }
            else if (remainder == 1) { level_counter_ones.sprite = one; }
            else if (remainder == 2) { level_counter_ones.sprite = two; }
            else if (remainder == 3) { level_counter_ones.sprite = three; }
            else if (remainder == 4) { level_counter_ones.sprite = four; }
            else if (remainder == 5) { level_counter_ones.sprite = five; }
            else if (remainder == 6) { level_counter_ones.sprite = six; }
            else if (remainder == 7) { level_counter_ones.sprite = seven; }
            else if (remainder == 8) { level_counter_ones.sprite = eight; }
            else if (remainder == 9) { level_counter_ones.sprite = nine; }

        }
    }
}
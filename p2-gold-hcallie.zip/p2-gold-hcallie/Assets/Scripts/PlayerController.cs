using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    private Rigidbody2D rb;
    private Animator anim;
    private ObjectInfo info;
    private SpriteRenderer sprite_renderer;

    public Transform rules_position;

    public RectTransform level_count_notification_text; // just used for level 1 notification

    public bool has_control = false; // true
    public bool is_on_ground = false;
    public bool is_on_ladder = false;
    bool game_start_sequence = true;

    public float vertical_boundary_min_height = -7f;
    public float vertical_boundary_max_height = 10f;

    private float movement_speed = 8f;
    private float jump_speed = 24f;
    // private float climb_speed = 4f;

    private float movement_x;
    private float movement_y;

    bool play_selected = true;

    public SpriteRenderer play_arrow;
    public SpriteRenderer level_select_arrow;

    // Vector3 level_reset_position;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        info = GetComponent<ObjectInfo>();
        sprite_renderer = GetComponent<SpriteRenderer>();

        play_arrow.enabled = true;
        level_select_arrow.enabled = false;

        // rules_position.position = rules_position.position + new Vector3(0f, -18f, 0f);

        // level_reset_position = new Vector3(-37, 0, 0);
    }

    void Update()
    {
        if (has_control)
        {
            // HORIZONTAL MOVEMENT
            movement_x = Input.GetAxis("Horizontal");

            if (movement_x > 0f) 
            { 
                rb.velocity = new Vector2(movement_x * movement_speed, rb.velocity.y);
                anim.SetBool("running_right", true);
                anim.SetBool("running_left", false);
                anim.SetBool("standing", false);
            }
            else if (movement_x < 0f)
            {
                rb.velocity = new Vector2(movement_x * movement_speed, rb.velocity.y);
                anim.SetBool("running_right", false);
                anim.SetBool("running_left", true);
                anim.SetBool("standing", false);
            }
            else
            {    
                rb.velocity = new Vector2(movement_x * movement_speed, rb.velocity.y);
                anim.SetBool("running_right", false);
                anim.SetBool("running_left", false);
                anim.SetBool("standing", true);
            }

            // VERTICAL MOVEMENT

            if (Input.GetKeyDown(KeyCode.Space) && is_on_ground) // Jump
            {
                if (info.normal_gravity) { rb.velocity = new Vector2(rb.velocity.x, jump_speed); }
                else { rb.velocity = new Vector2(rb.velocity.x, (-1 * jump_speed)); }
                
            }

            // if ((Input.GetAxis("Vertical") > 0) && is_on_ladder) // Climb up
            // {
            //     rb.velocity = new Vector2(rb.velocity.x, climb_speed);
            // }
            // else if ((Input.GetAxis("Vertical") < 0) && is_on_ladder) // Climb down
            // {
            //     rb.velocity = new Vector2(rb.velocity.x, -1 * climb_speed);
            // }
        }

        if (game_start_sequence) {

            movement_x = Input.GetAxis("Vertical");

            if (movement_x > 0f) 
            { 
                play_selected = true;
                play_arrow.enabled = true;
                level_select_arrow.enabled = false;

            }
            else if (movement_x < 0f)
            {
                play_selected = false;
                play_arrow.enabled = false;
                level_select_arrow.enabled = true;
            }

            if (play_selected && Input.GetKeyDown(KeyCode.Return)) // Start game
            {
                transform.position = new Vector3(-5.5f, 0f, 0f);
                info.level_reset_position = new Vector3(-5.5f, 0f, 0f);
                
                info.num_lives = 3;

                game_start_sequence = false;

                StartCoroutine(LevelCountNotification());
            }
            if (!play_selected && Input.GetKeyDown(KeyCode.Return))
            {
                Debug.Log("Moving Rules");
                rules_position.position += new Vector3(0f, 9.5f, 0f);
            }
        }

        // if (Input.GetKeyDown(KeyCode.Alpha2))
        // {
        //     // transform.position = new Vector3(204f, 0f, 0f);
        //     transform.position = new Vector3(627f, 0f, 0f);
        //     info.level = 5; // TODO

        //     game_start_sequence = false;
        // }
        
        // IF PLAYER FALLS
        if (((transform.position.y < vertical_boundary_min_height) || (transform.position.y > vertical_boundary_max_height)) && info.num_lives != 1) // Reset to start of last level
        {
            if (transform.position.y > vertical_boundary_max_height) // If too high, flip graviity
            {
                rb.gravityScale *= -1; // flip gravity
                sprite_renderer.flipY = !sprite_renderer.flipY; // flip sprite
                info.normal_gravity = !info.normal_gravity; // update info
            }

            transform.position = info.level_reset_position;
            info.num_lives -= 1;

            if (info.level_reset_position.x != -37f) { StartCoroutine(LevelCountNotification()); } // If on start screen, don't show level notification
        }

        if (((transform.position.y < vertical_boundary_min_height) || (transform.position.y > vertical_boundary_max_height)) && (info.num_lives <= 1)) { ResetGame(); } // Reset game
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        Debug.Log("[PlayerController] Collision Enter");

        if (other.gameObject.CompareTag("Ground") || other.gameObject.CompareTag("SolidBlock") || other.gameObject.CompareTag("PushBlock"))
        {
            is_on_ground = true;
        }

        if (other.gameObject.CompareTag("Ladder"))
        {
            is_on_ladder = true;
        }
    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Ground") || other.gameObject.CompareTag("SolidBlock") || other.gameObject.CompareTag("PushBlock"))
        {
            is_on_ground = true;
        }

        if (other.gameObject.CompareTag("Ladder"))
        {
            is_on_ladder = true;
        }
    }

    void OnCollisionExit2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Ground") || other.gameObject.CompareTag("SolidBlock") || other.gameObject.CompareTag("PushBlock"))
        {
            is_on_ground = false;
        }

        if (other.gameObject.CompareTag("Ladder"))
        {
            is_on_ladder = false;
        }
    }

    void ResetGame()
    {
        Scene current_scene = SceneManager.GetActiveScene();
        int scene_build_index = current_scene.buildIndex;

        SceneManager.LoadScene(scene_build_index);

        Debug.Log("Loaded.");
    }

    IEnumerator LevelCountNotification()
    {
        Debug.Log("[TeleportObject] Called notification coroutine");
        // yield return new WaitForSeconds(1.0f);

        Vector3 pos_i = level_count_notification_text.anchoredPosition;
        Vector3 pos_f = pos_i - new Vector3(0f, 350f, 0f);

        // Move text down, wait, move back up
        StartCoroutine(MoveObjectOverTime(level_count_notification_text, pos_i, pos_f, 1f));
        
        yield return new WaitForSeconds(2.0f);

        StartCoroutine(MoveObjectOverTime(level_count_notification_text, pos_f, pos_i, 1f));

        yield break;
    }

    public static IEnumerator MoveObjectOverTime(RectTransform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {

        Debug.Log("[TeleportObject] Called move object over time");

        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.anchoredPosition = newPosition;

            yield return null;
        }

        target.anchoredPosition = finalPosition;
    }
}

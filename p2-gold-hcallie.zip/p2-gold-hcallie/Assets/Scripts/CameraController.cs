using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject player;
    Vector3 camera_offset;

    // private float camera_y;

    void Start()
    {
        camera_offset = new Vector3(0f, 1.25f, -10f);
        transform.position = new Vector3(player.transform.position.x, 0f, player.transform.position.z) + camera_offset;
    }

    void LateUpdate()
    {
        // if (player.transform.position.y > 3f)
        // {
        //     float player_delta = player.transform.position.y - 3f;
        //     camera_offset.y += player_delta / 2;
        // }
        // else 
        // {
        //     camera_offset.y = 0f;
        // }

        transform.position = new Vector3(player.transform.position.x, 0f, player.transform.position.z) + camera_offset;
    }
}

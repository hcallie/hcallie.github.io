using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collector : MonoBehaviour
{
    public ObjectInfo info;

    void OnTriggerEnter2D(Collider2D obj_collided_with)
    {
        Debug.Log("Collector: Trigger called");

        // GameObject obj_collided_with = collider.gameObject;
        
        if (obj_collided_with.tag == "Heart")
        {
            Debug.Log("Collector: Trigger called - delete");

            Destroy(obj_collided_with.gameObject);
            
            if (info.num_lives != 5)
            {
                info.num_lives++;
            }
        }        
    }
}

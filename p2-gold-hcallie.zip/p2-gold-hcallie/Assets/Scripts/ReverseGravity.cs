using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReverseGravity : MonoBehaviour
{
    GameObject object_to_flip;

    void OnTriggerEnter2D(Collider2D object_to_flip)
    {
        if (object_to_flip.tag != "Portal")
        {
            object_to_flip.gameObject.GetComponent<Rigidbody2D>().gravityScale *= -1; // flip gravity
            object_to_flip.gameObject.GetComponent<SpriteRenderer>().flipY = !object_to_flip.gameObject.GetComponent<SpriteRenderer>().flipY; // flip sprite
            object_to_flip.gameObject.GetComponent<ObjectInfo>().normal_gravity = !object_to_flip.gameObject.GetComponent<ObjectInfo>().normal_gravity; // update info
        }
    }

    // public void ReverseObjectGravity(Collider2D object_to_flip) // used for starting new levels
    // {
    //     object_to_flip.gameObject.GetComponent<Rigidbody2D>().gravityScale *= -1; // flip gravity
    //     object_to_flip.gameObject.GetComponent<SpriteRenderer>().flipY = !object_to_flip.gameObject.GetComponent<SpriteRenderer>().flipY; // flip sprite
    //     object_to_flip.gameObject.GetComponent<ObjectInfo>().normal_gravity = !object_to_flip.gameObject.GetComponent<ObjectInfo>().normal_gravity; // update info
    // }
}

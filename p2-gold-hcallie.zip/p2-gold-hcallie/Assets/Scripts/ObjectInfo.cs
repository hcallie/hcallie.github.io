using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectInfo : MonoBehaviour
{
    public bool normal_gravity;

    public int level;
    public Vector3 level_reset_position;

    public int num_lives;

    public bool game_start_sequence;

    void Start()
    {
        normal_gravity = true;
        level = 1;
        level_reset_position = new Vector3(-37, 0, 0);
        num_lives = 0;

        game_start_sequence = true;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UILifeController : MonoBehaviour
{
    public ObjectInfo player_info;

    public Image life1;
    public Image life2;
    public Image life3;
    public Image life4;
    public Image life5;

    void Start()
    {
        life1.enabled = false;
        life2.enabled = false;
        life3.enabled = false;
        life4.enabled = false;
        life5.enabled = false;
    }

    void Update()
    {
        // ---------------- LIFE UI ---------------- //
        if (player_info.num_lives >= 0 && !player_info.game_start_sequence) { life1.enabled = true; }
        else { life1.enabled = false; }

        if (player_info.num_lives >= 1) { life2.enabled = true; }
        else { life2.enabled = false; }

        if (player_info.num_lives >= 2) { life3.enabled = true; }
        else { life3.enabled = false; }

        if (player_info.num_lives >= 3) { life4.enabled = true; }
        else { life4.enabled = false; }

        if (player_info.num_lives >= 4) { life5.enabled = true; }
        else { life5.enabled = false; }
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalJuice : MonoBehaviour
{
    public Transform transform;

    public float movement_amount = 0.1f;
    public float movement_time = 0.5f;

    void Start()
    {
        transform = GetComponent<Transform>();

        StartCoroutine(MakePortalMove());
    }

    IEnumerator MakePortalMove()
    {
        while (true)
        {
            Vector3 pos_i = transform.position;
            Vector3 pos_f = pos_i + new Vector3(0f, movement_amount, 0f);

            yield return StartCoroutine(MoveObjectOverTime(transform, pos_i, pos_f, movement_time));
            yield return StartCoroutine(MoveObjectOverTime(transform, pos_f, pos_i, movement_time));

            yield return null;
        }
    }

    public static IEnumerator MoveObjectOverTime(Transform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {

        Debug.Log("[PortalJuice] Called move object over time");

        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.position = newPosition;

            yield return null;
        }

        target.position = finalPosition;
    }
}

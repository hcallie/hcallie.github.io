using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DecorationJuice : MonoBehaviour
{
    public Transform decoration_transform;

    public float movement_amount = 1.5f;
    public float movement_time = 0.5f;

    void Start()
    {
        decoration_transform = GetComponent<Transform>();
    }

    void OnTriggerEnter2D(Collider2D disturbance_object)
    {

        Debug.Log("[DecorationJuice] Triggered");

        if (disturbance_object.tag == "Player" || disturbance_object.tag == "PushBlock")
        {
            // Make decoration wiggle
            StartCoroutine(MakeDecorationWiggle());
        }
    }

    IEnumerator MakeDecorationWiggle()
    {
        Debug.Log("[DecorationJuice] Coroutine called");
        Vector3 scale_i = transform.localScale;
        Vector3 scale_f = scale_i + new Vector3(movement_amount, 2 * movement_amount, 0f);

        yield return StartCoroutine(MoveObjectOverTime(transform, scale_i, scale_f, movement_time));
        yield return StartCoroutine(MoveObjectOverTime(transform, scale_f, scale_i, movement_time));

        yield return null;
    }

    public static IEnumerator MoveObjectOverTime(Transform target, Vector3 initialScale, Vector3 finalScale, float duration)
    {

        Debug.Log("[PortalJuice] Called move object over time");

        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newScale = Vector3.Lerp(initialScale, finalScale, progress);

            target.localScale = newScale;

            yield return null;
        }

        target.localScale = finalScale;
    }
}

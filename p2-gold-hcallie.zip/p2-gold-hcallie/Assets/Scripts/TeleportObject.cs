using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TeleportObject : MonoBehaviour
{
    public GameObject self;
    // public ObjectInfo player_info;

    // public GameObject level_count_notification_text_obj;

    public RectTransform level_count_notification_text;

    Collider2D object_to_teleport;
    public Vector3 where_to_teleport;

    void Start()
    {
        // level_count_notification_text = level_count_notification_text_obj.GetComponent<RectTransform>();
    }

    void OnTriggerEnter2D(Collider2D object_to_teleport)
    {
        if (!object_to_teleport.gameObject.GetComponent<ObjectInfo>().normal_gravity) // if anti-gravity, switch to normal gravity
        {
            // public void ReverseObjectGravity(Collider2D object_to_flip) // used for starting new levels

            object_to_teleport.gameObject.GetComponent<Rigidbody2D>().gravityScale *= -1; // flip gravity
            object_to_teleport.gameObject.GetComponent<SpriteRenderer>().flipY = !object_to_teleport.gameObject.GetComponent<SpriteRenderer>().flipY; // flip sprite
            object_to_teleport.gameObject.GetComponent<ObjectInfo>().normal_gravity = !object_to_teleport.gameObject.GetComponent<ObjectInfo>().normal_gravity; // update info
        }

        object_to_teleport.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 0f, 0f);
        object_to_teleport.gameObject.GetComponent<Transform>().position = new Vector3(where_to_teleport.x, where_to_teleport.y, 0f);

        if ((object_to_teleport.gameObject.tag == "Player") && (self.tag == "Gem")) // if player leveling up
        {
            object_to_teleport.gameObject.GetComponent<ObjectInfo>().level++;
            object_to_teleport.gameObject.GetComponent<ObjectInfo>().level_reset_position = where_to_teleport;
            Debug.Log("[TeleportObject] Leveled up! Level is now: " + object_to_teleport.gameObject.GetComponent<ObjectInfo>().level);

            StartCoroutine(LevelCountNotification());
        }
    }

    IEnumerator LevelCountNotification()
    {
        Debug.Log("[TeleportObject] Called notification coroutine");
        // yield return new WaitForSeconds(1.0f);

        Vector3 pos_i = level_count_notification_text.anchoredPosition;
        Vector3 pos_f = pos_i - new Vector3(0f, 350f, 0f);

        // Move text down, wait, move back up
        StartCoroutine(MoveObjectOverTime(level_count_notification_text, pos_i, pos_f, 1f));
        
        yield return new WaitForSeconds(2.0f);

        StartCoroutine(MoveObjectOverTime(level_count_notification_text, pos_f, pos_i, 1f));

        yield break;
    }

    public static IEnumerator MoveObjectOverTime(RectTransform target, Vector3 initialPosition, Vector3 finalPosition, float duration)
    {

        Debug.Log("[TeleportObject] Called move object over time");

        float initialTime = Time.time;
        float progress = (Time.time - initialTime) / duration;

        while(progress < 1.0f)
        {
            progress = (Time.time - initialTime) / duration;
            Vector3 newPosition = Vector3.Lerp(initialPosition, finalPosition, progress);

            target.anchoredPosition = newPosition;

            yield return null;
        }

        target.anchoredPosition = finalPosition;
    }
}

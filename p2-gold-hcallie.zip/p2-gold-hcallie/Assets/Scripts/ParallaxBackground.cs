using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxBackground : MonoBehaviour
{
    public Transform camera_transform;
    private Vector3 prev_camera_position;

    public float parallax_divider = 2.0f;
    private float background_size;

    void Start()
    {
        // camera_transform = Camera.main.Transform;
        prev_camera_position = camera_transform.position;
        Sprite sprite = GetComponent<SpriteRenderer>().sprite;
        Texture2D texture = sprite.texture;
        background_size = texture.width / sprite.pixelsPerUnit;
    }

    void LateUpdate()
    {
        Vector3 delta = camera_transform.position - prev_camera_position;

        transform.position += delta / parallax_divider;
        prev_camera_position = camera_transform.position;

        // if (Mathf.Abs(camera_transform.position.x - transform.position.x) >= background_size)
        // {
        //     float position_offset = (camera_transform.position.x - transform.position.x) % background_size;
        //     transform.position = new Vector3(camera_transform.position.x + position_offset, transform.position.y);
        // }
    }
}
